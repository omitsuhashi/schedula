"""OpenAPI schemas for the app envelopes and the pinned public engine contract."""

import copy
import json
from pathlib import Path

from shift_schedula import get_schema

SCHEMA_VERSION = json.loads(
    (Path(__file__).resolve().parents[1] / "vendor/schedula/manifest.json").read_text()
)["schema_version"]


def ref(name):
    return {"$ref": f"#/components/schemas/{name}"}


def engine_schema(kind):
    name = f"Engine{kind.title()}"

    def embed(value):
        if isinstance(value, list):
            return [embed(item) for item in value]
        if isinstance(value, dict):
            return {
                key: (
                    f"#/components/schemas/{name}{item[1:]}"
                    if key == "$ref" and item.startswith("#")
                    else embed(item)
                )
                for key, item in value.items()
                if key != "$id"
            }
        return value

    # Rebase local references, including the recursive Response reference.
    # /api/schema/{kind} still returns the unchanged public schema with its URN.
    return embed(get_schema(kind, SCHEMA_VERSION))


def record(properties, required=None, **extra):
    return {
        "type": "object",
        "properties": properties,
        "required": required or list(properties),
        **extra,
    }


SCHEMAS = {
    f"Engine{kind.title()}": engine_schema(kind)
    for kind in ("request", "response", "solution", "verification")
}
SCHEMAS["CheckedPlan"] = copy.deepcopy(SCHEMAS["EngineVerification"])
SCHEMAS["CheckedPlan"]["properties"]["solution"] = {
    "description": "検証した元の解。不正な解も診断とともにそのまま返す。"
}
SCHEMAS["CheckedPlan"]["required"].append("solution")
SCHEMAS["BaselineSnapshot"] = copy.deepcopy(SCHEMAS["EngineRequest"]["properties"]["baseline"])
SCHEMAS["BaselineSnapshot"]["properties"].update(
    source_request=ref("EngineRequest"), source_solution=ref("EngineSolution")
)
SCHEMAS.update(
    Error=record({"error": {"type": "string"}, "message": {"type": "string"}}),
    Runtime=record(
        {
            **{
                key: {"type": "string"}
                for key in (
                    "version",
                    "schema_version",
                    "commit",
                    "sha256",
                    "wheel",
                    "ortools_version",
                    "repository",
                    "license",
                    "build_command",
                )
            },
            "max_search_seconds": {"type": "integer"},
        }
    ),
    PlanSource=record(
        {
            "id": {"type": "string"},
            "request": ref("EngineRequest"),
            "solution": ref("EngineSolution"),
        }
    ),
    VerifyInput=record({"request": ref("EngineRequest"), "solution": ref("EngineSolution")}),
    CompareInput=record(
        {
            "request": ref("EngineRequest"),
            "modes": {
                "type": "array",
                "minItems": 1,
                "maxItems": 2,
                "items": {"enum": ["preserve_assigned", "rebuild"]},
            },
            "source": ref("PlanSource"),
        },
        ["request", "modes"],
    ),
    ComparedPlan=record(
        {
            "mode": {"enum": ["preserve_assigned", "rebuild"]},
            "request": ref("EngineRequest"),
            "result": {
                "anyOf": [
                    ref("EngineResponse"),
                    record(
                        {
                            "status": {"const": "ENGINE_ERROR"},
                            "solution": {"type": "null"},
                            "verification": record(
                                {"performed": {"const": False}, "valid": {"type": "null"}}
                            ),
                        }
                    ),
                ]
            },
        }
    ),
    WeekWindow=record(
        copy.deepcopy(SCHEMAS["EngineRequest"]["properties"]["planning_window"]["properties"]),
        ["start", "end", "timezone"],
    ),
    Interval=copy.deepcopy(SCHEMAS["EngineRequest"]["$defs"]["interval"]),
    StoredPlan=record(
        {
            "id": {"type": "string"},
            "label": {"type": "string"},
            "request": {"type": "object"},
            "result": {"type": "object", "description": "求解・再検証の結果、または解のない試行。"},
            "evidence": {"description": "元のメタデータ。解の重複を保存しない。"},
        },
        ["id", "label", "request", "result"],
        additionalProperties=False,
    ),
    Session=record(
        {
            "format": {"const": "schedula-app/1"},
            "engine": record(
                {
                    key: {"type": "string"}
                    for key in ("version", "schema_version", "commit", "sha256")
                },
                additionalProperties=False,
            ),
            "input": {"type": "string", "description": "未完成のJSON下書きも文字列として保持。"},
            "plans": {"type": "array", "items": ref("StoredPlan")},
            "selected": {"type": ["string", "null"]},
            "baseline": {"type": ["string", "null"]},
            "edit": {
                "anyOf": [
                    record(
                        {"request": {"type": "object"}, "solution": {"type": "object"}},
                        additionalProperties=False,
                    ),
                    {"type": "null"},
                ]
            },
        },
        additionalProperties=False,
    ),
)

ERRORS = {
    code: {
        "description": description,
        "content": {"application/json": {"schema": ref("Error")}},
    }
    for code, description in {
        400: "JSON・本文長・操作内容が不正（INVALID_JSON / INVALID_LENGTH / INVALID_OPERATION）",
        403: "HostまたはOriginを拒否",
        409: "他の処理が実行中（BUSY）",
        413: "本文が8 MiBを超える、または空",
        415: "application/json以外の本文",
        500: "処理が完了しない（ENGINE_ERROR）",
    }.items()
}

SEARCH_ERRORS = {
    **ERRORS,
    400: {
        **ERRORS[400],
        "description": ERRORS[400]["description"] + "、探索予算超過（SEARCH_LIMIT）",
    },
}


def post_contract(body, response):
    return {
        "requestBody": {"required": True, "content": {"application/json": {"schema": body}}},
        "responses": {
            "200": {
                "description": "操作結果（有効性・需要充足・最適性は個別に確認）",
                "content": {"application/json": {"schema": response}},
            },
        },
    }


# App envelopes remain strict; the public engine schemas stay authoritative.
version_field = {"type": "integer", "minimum": 0}
identifier = {"type": "string"}
nullable_id = {"type": ["string", "null"]}
edit_schema = SCHEMAS["Session"]["properties"]["edit"]
base = {"session_id": identifier, "version": version_field}
SCHEMAS.update(
    CreateSession=record(
        {"input": {"type": "string"}, "edit": edit_schema}, ["input"], additionalProperties=False
    ),
    DraftCommand=record(
        {"expected_version": version_field, "input": {"type": "string"}, "edit": edit_schema},
        additionalProperties=False,
    ),
    PlanCommand=record(
        {
            "expected_version": version_field,
            "request": ref("EngineRequest"),
            "label": {"type": "string"},
        },
        ["expected_version", "request"],
        additionalProperties=False,
    ),
    ComparisonCommand=record(
        {
            "expected_version": version_field,
            "request": ref("EngineRequest"),
            "modes": {**SCHEMAS["CompareInput"]["properties"]["modes"], "uniqueItems": True},
            "baseline_plan_id": identifier,
        },
        ["expected_version", "request", "modes"],
        additionalProperties=False,
    ),
    EditCommand=record(
        {
            "expected_version": version_field,
            "request": ref("EngineRequest"),
            "solution": ref("EngineSolution"),
            "label": {"type": "string"},
        },
        ["expected_version", "request", "solution"],
        additionalProperties=False,
    ),
    AdoptCommand=record(
        {"expected_version": version_field, "plan_id": identifier}, additionalProperties=False
    ),
    VersionCommand=record({"expected_version": version_field}, additionalProperties=False),
    CommandReceipt=record(
        {
            **base,
            "plan_ids": {"type": "array", "items": identifier},
            "result": {"type": ["object", "null"]},
        },
        additionalProperties=False,
    ),
    SessionOverview=record(
        {
            **base,
            **{
                key: SCHEMAS["Session"]["properties"][key]
                for key in ("engine", "input", "selected", "baseline", "edit")
            },
            "plan_count": {"type": "integer", "minimum": 0},
        },
        additionalProperties=False,
    ),
    PlanDetail=record(
        {
            **base,
            "plan_id": identifier,
            **{
                key: value
                for key, value in SCHEMAS["StoredPlan"]["properties"].items()
                if key != "id"
            },
        },
        [*base, "plan_id", "label", "request", "result"],
        additionalProperties=False,
    ),
)
number = {"type": "number"}


def array(items):
    return {"type": "array", "items": items}


SCHEMAS["PersonSummary"] = record(
    {
        **{key: number for key in ("minutes", "work_days", "holidays", "waiting")},
        "bounds": array(
            record(
                {
                    "id": identifier,
                    "interval": ref("Interval"),
                    "actual": number,
                    "min": {"type": ["number", "null"]},
                    "max": {"type": ["number", "null"]},
                }
            )
        ),
        "preferences": array(
            record(
                {
                    "id": identifier,
                    "type": identifier,
                    "interval": ref("Interval"),
                    "actual": number,
                    "missed": number,
                    "penalty": number,
                }
            )
        ),
    }
)
SCHEMAS["Coverage"] = record(
    {
        "demand_id": identifier,
        "role_id": identifier,
        "priority": {"type": "integer"},
        "interval": ref("Interval"),
        **{key: number for key in ("required", "assigned", "missing", "person_minutes")},
    }
)
SCHEMAS["PlanSummary"] = record(
    {
        "plan_id": identifier,
        "label": identifier,
        "has_solution": {"type": "boolean"},
        "status": identifier,
        "verification": record(
            {
                "performed": {"type": "boolean"},
                "valid": {"type": ["boolean", "null"]},
                "violations": array({"type": "object"}),
            },
            ["performed", "valid"],
        ),
        "demand_satisfied": {"type": ["boolean", "null"]},
        **{
            key: {"type": ["object", "null"]}
            for key in (
                "shortage_summary",
                "fairness_summary",
                "change_summary",
                "priority_summary",
                "cost_summary",
                "continuity_summary",
                "diagnosis_result",
            )
        },
        "duty_balance_summary": {"type": ["array", "null"], "items": {"type": "object"}},
        "objectives": array({"type": "object"}),
        "diagnostics": array({"type": "object"}),
    }
)
SCHEMAS["PlanList"] = record({**base, "plans": array(ref("PlanSummary"))})
SCHEMAS["ComparisonRow"] = record(
    {
        **SCHEMAS["PlanSummary"]["properties"],
        "common_objectives": array({"type": "object"}),
        "additional_objectives": array({"type": "object"}),
        "employee_totals": array(
            record(
                {
                    "employee_id": identifier,
                    "label": identifier,
                    **{key: number for key in ("minutes", "work_days", "holidays", "waiting")},
                }
            )
        ),
    }
)
SCHEMAS["ComparisonView"] = record({**base, "plans": array(ref("ComparisonRow"))})
shift_schema = SCHEMAS["EngineSolution"]["$defs"]["solution"]["properties"]["shifts"]["items"]
# EngineSolution local refs have already been rebased by engine_schema.
common_view = {
    **base,
    "plan_id": identifier,
    "status": identifier,
    "timezone": identifier,
    "coverage": array(ref("Coverage")),
    "shortage_summary": {"type": ["object", "null"]},
}
SCHEMAS["MonthlyView"] = record(
    {
        **common_view,
        "planning_window": SCHEMAS["EngineRequest"]["properties"]["planning_window"],
        "dates": array(identifier),
        "employees": array(
            record(
                {
                    "employee_id": identifier,
                    "label": identifier,
                    "summary": ref("PersonSummary"),
                    "cells": array(
                        record(
                            {
                                "date": identifier,
                                "starting_shifts": array(shift_schema),
                                "continuing_shifts": array(shift_schema),
                            }
                        )
                    ),
                }
            )
        ),
    }
)
SCHEMAS["EmployeeView"] = record(
    {
        **common_view,
        "employee_id": identifier,
        "label": identifier,
        "summary": ref("PersonSummary"),
        "shifts": SCHEMAS["EngineSolution"]["$defs"]["solution"]["properties"]["shifts"],
        "assignments": SCHEMAS["EngineSolution"]["$defs"]["solution"]["properties"]["assignments"],
    }
)
ERRORS[404] = {
    "description": "不明なsession/plan/employee",
    "content": {"application/json": {"schema": ref("Error")}},
}
ERRORS[409]["description"] = (
    "BUSY / VERSION_CONFLICT / INVALID_STATE / INCOMPATIBLE（current_versionは競合時）"
)
SCHEMAS["Error"]["properties"].update(current_version=version_field, result=ref("CheckedPlan"))
SEARCH_ERRORS[404] = ERRORS[404]
