"""Verify an operator's saved JSON with the application's existing restore boundary."""

import argparse
import json
import sys
from pathlib import Path

from server import MAX_BODY_BYTES, finite_float, reject_constant, runtime, unique_object
from workflow import restore


def main():
    parser = argparse.ArgumentParser(description="保存JSONを固定エンジンで再検証する")
    parser.add_argument("file", type=Path)
    args = parser.parse_args()
    try:
        with args.file.open("rb") as source:
            raw = source.read(MAX_BODY_BYTES + 1)
        if len(raw) > MAX_BODY_BYTES:
            raise ValueError("File too large")
        document = json.loads(
            raw,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
            parse_float=finite_float,
        )
        engine = runtime()
        checked = restore(document, engine)
    except Exception:
        # The saved document and engine diagnostics can contain customer information.
        print("保存JSONの読取・版確認・再検証に失敗しました。", file=sys.stderr)
        return 1
    print(
        json.dumps(
            {
                "restorable": True,
                "plans": len(checked["plans"]),
                "engine_version": engine["version"],
                "schema_version": engine["schema_version"],
                "engine_commit": engine["commit"],
                "wheel_sha256": engine["sha256"],
            }
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
