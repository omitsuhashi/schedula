"""Explicit session mutations; engine work precedes the final version check."""

import copy
from uuid import uuid4

from shift_schedula import solve

from store import StateError, conflict, encode, plan_in
from workflow import (
    IncompatibleVersion,
    InvalidOperation,
    InvalidPlan,
    baseline_snapshot,
    checked_plan,
    compare,
    restore,
)


def fields(body, required, optional=()):
    if not required <= body.keys() or body.keys() - required - set(optional):
        raise InvalidOperation("操作の必須項目・未対応項目を確認してください。")


def edit_value(value):
    if value is not None and (
        not isinstance(value, dict)
        or set(value) != {"request", "solution"}
        or not all(isinstance(value[key], dict) for key in ("request", "solution"))
    ):
        raise InvalidOperation("修正途中は元入力と解のオブジェクトで指定してください。")


def new_plan(body, result, default):
    label = body.get("label", default)
    if not isinstance(label, str) or not isinstance(body.get("request"), dict):
        raise InvalidOperation("名称は文字列、元入力はオブジェクトで指定してください。")
    return {
        "id": f"plan_{uuid4()}",
        "label": label,
        "request": copy.deepcopy(body["request"]),
        "result": result,
    }


def receipt(session_id, version, plan_ids=(), result=None):
    return {
        "session_id": session_id,
        "version": version,
        "plan_ids": list(plan_ids),
        "result": result,
    }


def create(store, body):
    fields(body, {"input"}, {"edit"})
    if not isinstance(body["input"], str):
        raise InvalidOperation("入力下書きは文字列で指定してください。")
    edit_value(body.get("edit"))
    return receipt(store.create(body), 0)


def import_document(store, body):
    try:
        document = restore(body, store.engine)
    except IncompatibleVersion as failure:
        raise StateError(409, "INCOMPATIBLE_VERSION", str(failure)) from failure
    except InvalidPlan as failure:
        raise StateError(400, "INVALID_PLAN", str(failure), result=failure.result) from failure
    return receipt(store.create(document), 0, [p["id"] for p in document["plans"]])


def execute(store, session_id, operation, body, plan_id=None):
    required, optional = {
        "draft": ({"input", "edit"}, ()),
        "plans": ({"request"}, ("label",)),
        "comparisons": ({"request", "modes"}, ("baseline_plan_id",)),
        "edits": ({"request", "solution"}, ("label",)),
        "adopt": ({"plan_id"}, ()),
        "delete": (set(), ()),
    }[operation]
    fields(body, required | {"expected_version"}, optional)
    state = store.read(session_id)
    expected = body["expected_version"]
    conflict(state, expected)
    additions, deletions, ids, result = [], [], [], None
    if operation == "draft":
        if not isinstance(body["input"], str):
            raise InvalidOperation("入力下書きは文字列で指定してください。")
        edit_value(body["edit"])
        state.update(input=body["input"], edit=body["edit"])
    elif operation == "plans":
        plan = new_plan(body, None, "計画案")
        plan["result"] = solve(body["request"])
        additions = [plan]
        result = {"status": plan["result"]["status"]}
    elif operation == "comparisons":
        request, modes = body["request"], body["modes"]
        if (
            not isinstance(request, dict)
            or not isinstance(modes, list)
            or (
                len(modes) not in (1, 2)
                or any(m not in ("preserve_assigned", "rebuild") for m in modes)
                or len(set(modes)) != len(modes)
            )
        ):
            raise InvalidOperation("再計画の入力・重複しない方式を指定してください。")
        supplied = "baseline_plan_id" in body
        if supplied == (request.get("baseline") is not None):
            raise InvalidOperation("保存済み基準IDと埋め込み基準の一方だけを指定してください。")
        payload = {"request": request, "modes": modes}
        if supplied:
            if not isinstance(body["baseline_plan_id"], str):
                raise InvalidOperation("基準計画IDは文字列で指定してください。")
            source = plan_in(state, body["baseline_plan_id"])
            require_usable(source)
            payload["source"] = {
                "id": source["id"],
                "request": source["request"],
                "solution": source["result"]["solution"],
            }
        values = compare(payload)
        additions = [new_plan(value, value["result"], value["mode"]) for value in values]
        result = {"modes": modes, "statuses": [p["result"]["status"] for p in additions]}
    elif operation == "edits":
        plan_in(state, plan_id)
        plan = new_plan(body, None, "手修正案")
        checked = checked_plan(body["request"], body["solution"])
        if not checked["verification"]["performed"] or checked["verification"]["valid"] is not True:
            raise StateError(
                400,
                "INVALID_PLAN",
                "修正した計画を保存できません。診断を確認してください。",
                result=checked,
            )
        plan["result"] = checked
        additions = [plan]
        state["edit"] = None
        result = {"status": checked["status"]}
    elif operation == "adopt":
        if not isinstance(body["plan_id"], str):
            raise InvalidOperation("計画IDは文字列で指定してください。")
        plan = plan_in(state, body["plan_id"])
        require_usable(plan)
        checked = checked_plan(plan["request"], plan["result"]["solution"])
        if checked["verification"]["valid"] is not True:
            raise StateError(
                409, "INVALID_STATE", "保存済み計画の再検証に失敗しました。", result=checked
            )
        snapshot = baseline_snapshot(
            {"id": plan["id"], "request": plan["request"], "solution": plan["result"]["solution"]}
        )
        next_input = copy.deepcopy(plan["request"])
        next_input.pop("fixed_parts", None)
        next_input.pop("replan_mode", None)
        next_input["objectives"] = [
            o for o in next_input.get("objectives", []) if o["metric"] != "plan_changes"
        ]
        next_input["baseline"] = snapshot
        state.update(input=encode(next_input), selected=plan["id"], baseline=plan["id"], edit=None)
        ids = [plan["id"]]
        result = {"status": checked["status"], "demand_satisfied": checked["demand_satisfied"]}
    elif operation == "delete":
        plan_in(state, plan_id)
        if plan_id in (state["selected"], state["baseline"]):
            raise StateError(409, "INVALID_STATE", "現在の採用案・基準計画は削除できません。")
        deletions = ids = [plan_id]
    version = store.update(state, expected, additions, deletions)
    return receipt(session_id, version, ids or [p["id"] for p in additions], result)


def require_usable(plan):
    result = plan["result"]
    if (
        plan["request"].get("problem_type") != "roster"
        or result.get("solution") is None
        or result.get("verification", {}).get("performed") is not True
        or result.get("verification", {}).get("valid") is not True
    ):
        raise StateError(409, "INVALID_STATE", "検証済みで解のある勤務計画を選んでください。")
