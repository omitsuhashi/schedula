"""Read models and CSV presentation, without engine calls or writes."""

import csv
import io
import re
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from commands import require_usable
from store import StateError, missing, plan_in


def instant(value):
    return datetime.fromisoformat(value).timestamp()


def overlap(a, b):
    return (
        max(
            0,
            min(instant(a["end"]), instant(b["end"]))
            - max(instant(a["start"]), instant(b["start"])),
        )
        / 60
    )


def work_minutes(shifts, period):
    return sum(
        overlap(seg["interval"], period) - sum(overlap(br, period) for br in seg["breaks"])
        for shift in shifts
        for seg in shift["segments"]
    )


def date_key(value, zone):
    return datetime.fromtimestamp(value, ZoneInfo(zone)).date()


def days(request):
    window = request["planning_window"]
    first = date_key(instant(window["start"]), window["timezone"])
    last = date_key(instant(window["end"]) - 0.001, window["timezone"])
    return [(first + timedelta(days=i)).isoformat() for i in range((last - first).days + 1)]


def touches(interval, day, zone):
    return (
        date_key(instant(interval["start"]), zone).isoformat()
        <= day
        <= date_key(instant(interval["end"]) - 0.001, zone).isoformat()
    )


def person_summary(request, solution, employee_id):
    shifts = [s for s in solution["shifts"] if s["employee_id"] == employee_id]
    assignments = [a for a in solution["assignments"] if a["employee_id"] == employee_id]
    dates, window = days(request), request["planning_window"]
    minutes = work_minutes(shifts, window)
    history = next(
        (
            e
            for e in request.get("continuity", {}).get("employees", [])
            if e["employee_id"] == employee_id
        ),
        {},
    )
    context = (
        shifts
        + history.get("actual_shifts", [])
        + [
            c
            for c in history.get("committed_shifts", [])
            if not any(s.get("committed_shift_id") == c["id"] for s in shifts)
        ]
    )
    bounds = [
        {
            "id": c["id"],
            "interval": c["interval"],
            "actual": work_minutes(context, c["interval"]),
            "min": c.get("min_minutes"),
            "max": c.get("max_minutes"),
        }
        for c in request.get("constraints", [])
        if c["type"] == "scheduled_minutes_bounds"
        and employee_id in c["employee_ids"]
        and c.get("interval")
    ]
    preferences = []
    for p in request.get("preferences", []):
        if (
            employee_id not in p["employee_ids"]
            or not p.get("interval")
            or p["type"] not in ("prefer_work", "avoid_work")
        ):
            continue
        actual = work_minutes(shifts, p["interval"])
        missed = (
            overlap(p["interval"], p["interval"]) - actual if p["type"] == "prefer_work" else actual
        )
        preferences.append(
            {
                "id": p["id"],
                "type": p["type"],
                "interval": p["interval"],
                "actual": actual,
                "missed": missed,
                "penalty": missed * p["penalty_per_minute"],
            }
        )
    return {
        "minutes": minutes,
        "work_days": len({s["work_day"] for s in shifts if s["work_day"] in dates}),
        "holidays": sum(
            not any(
                touches(seg["interval"], d, window["timezone"])
                for s in shifts
                for seg in s["segments"]
            )
            for d in dates
        ),
        "waiting": minutes - sum(overlap(a["interval"], window) for a in assignments),
        "bounds": bounds,
        "preferences": preferences,
    }


def coverage(request, solution):
    rows = []
    zone = ZoneInfo(request["planning_window"]["timezone"])
    for demand in request["demand"]:
        relevant = [
            a
            for a in solution["assignments"]
            if a["role_id"] == demand["role_id"] and overlap(a["interval"], demand["interval"]) > 0
        ]
        left, right = (instant(demand["interval"][key]) for key in ("start", "end"))
        points = sorted(
            {left, right}
            | {max(left, instant(a["interval"]["start"])) for a in relevant}
            | {min(right, instant(a["interval"]["end"])) for a in relevant}
        )
        for start, end in zip(points, points[1:], strict=False):
            assigned = sum(
                instant(a["interval"]["start"]) <= start and instant(a["interval"]["end"]) >= end
                for a in relevant
            )
            missing_people = max(0, demand["required_people"] - assigned)
            rows.append(
                {
                    "demand_id": demand["id"],
                    "priority": demand.get("priority", 0),
                    "role_id": demand["role_id"],
                    "interval": {
                        "start": datetime.fromtimestamp(start, zone).isoformat(),
                        "end": datetime.fromtimestamp(end, zone).isoformat(),
                    },
                    "required": demand["required_people"],
                    "assigned": assigned,
                    "missing": missing_people,
                    "person_minutes": missing_people * (end - start) / 60,
                }
            )
    return rows


def envelope(state):
    return {key: state[key] for key in ("session_id", "version")}


def session(state):
    return {
        **envelope(state),
        **{key: state[key] for key in ("engine", "input", "selected", "baseline", "edit")},
        "plan_count": len(state["plans"]),
    }


def summary(plan):
    result = plan["result"]
    values = {
        key: result.get(key)
        for key in (
            "status",
            "verification",
            "demand_satisfied",
            "shortage_summary",
            "fairness_summary",
            "change_summary",
            "priority_summary",
            "cost_summary",
            "duty_balance_summary",
            "continuity_summary",
            "diagnosis_result",
        )
    }
    return {
        "plan_id": plan["id"],
        "label": plan["label"],
        "has_solution": result.get("solution") is not None,
        **values,
        "objectives": result.get("objectives", []),
        "diagnostics": result.get("diagnostics", []),
    }


def detail(state, plan_id):
    plan = plan_in(state, plan_id)
    return {
        **envelope(state),
        "plan_id": plan["id"],
        **{k: v for k, v in plan.items() if k != "id"},
    }


def monthly(state, plan_id):
    plan = plan_in(state, plan_id)
    require_usable(plan)
    request, solution = plan["request"], plan["result"]["solution"]
    dates, zone = days(request), request["planning_window"]["timezone"]
    employees = []
    for employee in request["employees"]:
        shifts = [s for s in solution["shifts"] if s["employee_id"] == employee["id"]]
        employees.append(
            {
                "employee_id": employee["id"],
                "label": employee.get("label", employee["id"]),
                "summary": person_summary(request, solution, employee["id"]),
                "cells": [
                    {
                        "date": d,
                        "starting_shifts": [s for s in shifts if s["work_day"] == d],
                        "continuing_shifts": [
                            s
                            for s in shifts
                            if s["work_day"] != d
                            and any(touches(seg["interval"], d, zone) for seg in s["segments"])
                        ],
                    }
                    for d in dates
                ],
            }
        )
    return {
        **envelope(state),
        "plan_id": plan_id,
        "status": plan["result"]["status"],
        "timezone": zone,
        "planning_window": request["planning_window"],
        "dates": dates,
        "employees": employees,
        "coverage": coverage(request, solution),
        "shortage_summary": plan["result"].get("shortage_summary"),
    }


def employee(state, plan_id, employee_id):
    plan = plan_in(state, plan_id)
    require_usable(plan)
    request, solution = plan["request"], plan["result"]["solution"]
    person = next((e for e in request["employees"] if e["id"] == employee_id), None)
    if person is None:
        missing()
    return {
        **envelope(state),
        "plan_id": plan_id,
        "status": plan["result"]["status"],
        "timezone": request["planning_window"]["timezone"],
        "employee_id": employee_id,
        "label": person.get("label", employee_id),
        "summary": person_summary(request, solution, employee_id),
        "shifts": [s for s in solution["shifts"] if s["employee_id"] == employee_id],
        "assignments": [a for a in solution["assignments"] if a["employee_id"] == employee_id],
        "coverage": coverage(request, solution),
        "shortage_summary": plan["result"].get("shortage_summary"),
    }


def comparisons(state, ids):
    if len(ids) not in (1, 2) or len(set(ids)) != len(ids):
        raise StateError(400, "INVALID_OPERATION", "重複しない1〜2案を指定してください。")
    plans = [plan_in(state, i) for i in ids]
    keys = [[(o["id"], o["metric"]) for o in p["result"].get("objectives", [])] for p in plans]
    common = [key for key in keys[0] if all(key in sequence for sequence in keys)]
    if any([key for key in sequence if key in common] != common for sequence in keys):
        common = []
    rows = []
    for plan in plans:
        result = plan["result"]
        objectives = result.get("objectives", [])
        totals = []
        if (
            result.get("solution") is not None
            and result.get("verification", {}).get("valid") is True
        ):
            for e in plan["request"]["employees"]:
                s = person_summary(plan["request"], result["solution"], e["id"])
                totals.append(
                    {
                        "employee_id": e["id"],
                        "label": e.get("label", e["id"]),
                        **{k: s[k] for k in ("minutes", "work_days", "holidays", "waiting")},
                    }
                )
        rows.append(
            {
                **summary(plan),
                "common_objectives": [o for o in objectives if (o["id"], o["metric"]) in common],
                "additional_objectives": [
                    o for o in objectives if (o["id"], o["metric"]) not in common
                ],
                "employee_totals": totals,
            }
        )
    return {**envelope(state), "plans": rows}


def exported(state):
    return {
        key: state[key]
        for key in ("format", "engine", "input", "plans", "selected", "baseline", "edit")
    }


def shift_text(shift):
    return " / 分割間は非勤務 / ".join(
        f"{s['interval']['start']} → {s['interval']['end']}"
        + (
            " / 休憩 " + "、".join(f"{b['start']} → {b['end']}" for b in s["breaks"])
            if s["breaks"]
            else ""
        )
        for s in shift["segments"]
    )


def cell_text(cell):
    return (
        " / ".join(
            [shift_text(s) for s in cell["starting_shifts"]]
            + [
                f"継続勤務（開始日 {s['work_day']}） {shift_text(s)}"
                for s in cell["continuing_shifts"]
            ]
        )
        or "休日（勤務なし）"
    )


def waiting_intervals(shift, assignments, period, zone):
    for seg in shift["segments"]:
        left, right = (
            max(instant(seg["interval"]["start"]), instant(period["start"])),
            min(instant(seg["interval"]["end"]), instant(period["end"])),
        )
        if left >= right:
            continue
        occupied = [
            i
            for i in seg["breaks"]
            + [a["interval"] for a in assignments if a["employee_id"] == shift["employee_id"]]
            if instant(i["start"]) < right and instant(i["end"]) > left
        ]
        points = sorted(
            {left, right}
            | {max(left, instant(i["start"])) for i in occupied}
            | {min(right, instant(i["end"])) for i in occupied}
        )
        for start, end in zip(points, points[1:], strict=False):
            if not any(instant(i["start"]) < end and instant(i["end"]) > start for i in occupied):
                yield {
                    "start": datetime.fromtimestamp(start, zone).isoformat(),
                    "end": datetime.fromtimestamp(end, zone).isoformat(),
                }


def csv_export(state, kind):
    if kind not in ("monthly", "shifts", "demand"):
        missing()
    if state["selected"] is None:
        raise StateError(409, "INVALID_STATE", "採用案を選んでください。")
    plan = plan_in(state, state["selected"])
    require_usable(plan)
    request, solution, status = (
        plan["request"],
        plan["result"]["solution"],
        plan["result"]["status"],
    )
    zone = request["planning_window"]["timezone"]
    names = {e["id"]: e.get("label", e["id"]) for e in request["employees"]}
    if kind == "monthly":
        view = monthly(state, plan["id"])
        rows = [
            [
                "状態",
                "従業員ID",
                "名称",
                "勤務分数",
                "勤務開始日数",
                "完全休日数",
                "待機分数",
                *view["dates"],
            ]
        ]
        for e in view["employees"]:
            rows.append(
                [
                    status,
                    e["employee_id"],
                    e["label"],
                    *[e["summary"][k] for k in ("minutes", "work_days", "holidays", "waiting")],
                    *[cell_text(c) for c in e["cells"]],
                ]
            )
    elif kind == "demand":
        rows = [
            [
                "状態",
                "需要ID",
                "需要優先度",
                "役割ID",
                "開始",
                "終了",
                "タイムゾーン",
                "元必要人数",
                "配置人数",
                "不足人数",
                "不足人分",
            ]
        ]
        rows += [
            [
                status,
                c["demand_id"],
                c["priority"],
                c["role_id"],
                c["interval"]["start"],
                c["interval"]["end"],
                zone,
                c["required"],
                c["assigned"],
                c["missing"],
                c["person_minutes"],
            ]
            for c in coverage(request, solution)
        ]
    else:
        rows = [
            [
                "状態",
                "従業員ID",
                "名称",
                "勤務候補ID",
                "確定勤務ID",
                "勤務日",
                "区分",
                "開始",
                "終了",
                "タイムゾーン",
            ]
        ]
        for s in solution["shifts"]:
            prefix = [
                status,
                s["employee_id"],
                names[s["employee_id"]],
                s.get("candidate_id"),
                s.get("committed_shift_id"),
                s["work_day"],
            ]
            for seg in s["segments"]:
                rows.append(
                    [
                        *prefix,
                        "勤務区間（休憩・待機を含む）",
                        seg["interval"]["start"],
                        seg["interval"]["end"],
                        zone,
                    ]
                )
                rows += [[*prefix, "休憩", b["start"], b["end"], zone] for b in seg["breaks"]]
            rows += [
                [*prefix, "待機", i["start"], i["end"], zone]
                for i in waiting_intervals(
                    s, solution["assignments"], request["planning_window"], ZoneInfo(zone)
                )
            ]
            rows += [
                [*prefix, "非勤務（分割間）", a["interval"]["end"], b["interval"]["start"], zone]
                for a, b in zip(s["segments"], s["segments"][1:], strict=False)
            ]
        rows += [
            [
                status,
                a["employee_id"],
                names[a["employee_id"]],
                "",
                "",
                "",
                f"担当 {a['role_id']}",
                a["interval"]["start"],
                a["interval"]["end"],
                zone,
            ]
            for a in solution["assignments"]
        ]
    output = io.StringIO(newline="")
    output.write("\ufeff")
    writer = csv.writer(output, quoting=csv.QUOTE_ALL)
    for row in rows:
        texts = [
            str(int(value) if isinstance(value, float) and value.is_integer() else value)
            if value is not None
            else ""
            for value in row
        ]
        writer.writerow(
            ["'" + s if re.match(r"^[\s\ufeff]*[=+\-@]|^[\t\r\n]", s) else s for s in texts]
        )
    return output.getvalue()
