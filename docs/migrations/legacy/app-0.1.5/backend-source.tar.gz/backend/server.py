"""Local application HTTP boundary; scheduling rules belong to schedula."""

import argparse
import asyncio
import hashlib
import json
import math
import socket
import threading
from contextlib import asynccontextmanager
from importlib.metadata import version
from pathlib import Path
from typing import Annotated

import uvicorn
from fastapi import Depends, FastAPI, Request
from fastapi import Path as ApiPath
from fastapi.openapi.utils import get_openapi
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from shift_schedula import get_schema, solve
from starlette.concurrency import run_in_threadpool
from starlette.exceptions import HTTPException
from starlette.requests import ClientDisconnect

import commands
import queries
from api import ERRORS, SCHEMAS, SEARCH_ERRORS, post_contract, ref
from store import StateError, Store, encode
from workflow import InvalidOperation, baseline_snapshot, checked_plan, compare, restore, weeks

ROOT = Path(__file__).resolve().parents[1]
MAX_BODY_BYTES = 8 * 1024 * 1024
MAX_SEARCH_SECONDS = 60
EXAMPLES = [
    "complete",
    "partial",
    "overnight",
    "split",
    "replan",
    "large",
    "demand_priority",
    "continuity_month",
    "continuity_replan",
    "conflict_refinement",
    "scheduled_cost",
    "duty_balance",
    "continuity_duty_balance",
]


def reject_constant(value):
    raise ValueError(f"Non-finite JSON number: {value}")


def finite_float(value):
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("Non-finite JSON number")
    return number


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def runtime():
    manifest = json.loads((ROOT / "vendor/schedula/manifest.json").read_text())
    wheel = ROOT / "vendor/schedula" / manifest["wheel"]
    if hashlib.sha256(wheel.read_bytes()).hexdigest() != manifest["sha256"]:
        raise RuntimeError("同梱エンジンのハッシュが一致しません。")
    if version("shift-schedula") != manifest["version"]:
        raise RuntimeError("エンジンの版が一致しません。uv sync --locked を実行してください。")
    get_schema("request", manifest["schema_version"])
    return {
        **manifest,
        "ortools_version": version("ortools"),
        "max_search_seconds": MAX_SEARCH_SECONDS,
    }


@asynccontextmanager
async def lifespan(app):
    app.state.engine = runtime()
    app.state.store = Store(app.state.data_dir, app.state.engine)
    # ponytail: one calculation per local app; use workers when concurrency is needed.
    app.state.solve_lock = threading.Lock()
    if url := getattr(app.state, "url", None):
        print(f"schedula-app: {url}", flush=True)
    yield


app = FastAPI(
    title="schedula-app", lifespan=lifespan, version="0.1.0", docs_url=None, redoc_url=None
)
app.state.dev = False


def error(status, code, message):
    return JSONResponse(status_code=status, content={"error": code, "message": message})


@app.middleware("http")
async def local_boundary(request: Request, call_next):
    port = request.scope["server"][1]
    hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
    if app.state.dev:
        hosts.add("127.0.0.1:5173")
    host_headers = request.headers.getlist("host")
    origins = request.headers.getlist("origin")
    if len(host_headers) != 1 or host_headers[0] not in hosts:
        response = error(403, "HOST_REJECTED", "許可されていない Host です。")
    elif origins and (len(origins) != 1 or origins[0] != f"http://{host_headers[0]}"):
        response = error(403, "ORIGIN_REJECTED", "同じ画面から操作してください。")
    elif request.method != "GET" and request.headers.get("sec-fetch-site") == "cross-site":
        response = error(403, "ORIGIN_REJECTED", "同じ画面から操作してください。")
    else:
        response = await call_next(request)
    response.headers.update(
        {
            "Cache-Control": "no-store",
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer",
            "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; "
            "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
        }
    )
    return response


@app.exception_handler(HTTPException)
async def http_error(request: Request, exception: HTTPException):
    if exception.status_code == 404:
        return error(404, "NOT_FOUND", "指定の入口はありません。")
    detail = exception.detail
    return JSONResponse(
        status_code=exception.status_code,
        content=detail if isinstance(detail, dict) else {"detail": detail},
    )


@app.get(
    "/api/runtime",
    operation_id="runtime",
    summary="固定エンジンの版と探索上限",
    responses={
        200: {"content": {"application/json": {"schema": ref("Runtime")}}},
        403: ERRORS[403],
    },
)
def engine_runtime(request: Request):
    return request.app.state.engine


@app.get(
    "/api/schema/{kind}",
    operation_id="schema",
    summary="固定版エンジンの公開JSON Schema",
    responses={
        200: {"content": {"application/json": {"schema": {"type": "object"}}}},
        403: ERRORS[403],
        404: {
            "description": "未対応のSchema",
            "content": {"application/json": {"schema": ref("Error")}},
        },
    },
)
def request_schema(
    kind: Annotated[
        str,
        ApiPath(json_schema_extra={"enum": ["request", "response", "solution", "verification"]}),
    ],
    request: Request,
):
    if kind not in {"request", "response", "solution", "verification"}:
        return error(404, "NOT_FOUND", "指定の入口はありません。")
    return get_schema(kind, request.app.state.engine["schema_version"])


@app.get(
    "/api/examples/{name}",
    operation_id="example",
    summary="架空の勤務計画入力",
    responses={
        200: {"content": {"application/json": {"schema": ref("EngineRequest")}}},
        403: ERRORS[403],
        404: {
            "description": "未対応の入力例",
            "content": {"application/json": {"schema": ref("Error")}},
        },
    },
)
def example(
    name: Annotated[
        str,
        ApiPath(json_schema_extra={"enum": EXAMPLES}),
    ],
):
    if name not in EXAMPLES:
        return error(404, "NOT_FOUND", "指定の入口はありません。")
    return Response(
        (ROOT / f"backend/examples/{name}.json").read_bytes(), media_type="application/json"
    )


def reject(status, code, message):
    raise HTTPException(status, {"error": code, "message": message})


async def read_payload(request: Request):
    lengths = request.headers.getlist("content-length")
    if (
        request.headers.get("transfer-encoding")
        or len(lengths) != 1
        or len(lengths[0]) > 9
        or not lengths[0].isascii()
        or not lengths[0].isdigit()
    ):
        reject(400, "INVALID_LENGTH", "本文の長さを指定してください。")
    length = int(lengths[0])
    if not 0 < length <= MAX_BODY_BYTES:
        reject(413, "BODY_LIMIT", "入力は8 MiB以内にしてください。")
    if request.headers.get("content-type", "").split(";", 1)[0].strip() != "application/json":
        reject(415, "JSON_REQUIRED", "JSONを送信してください。")
    try:
        raw = bytearray()
        async with asyncio.timeout(10):
            async for chunk in request.stream():
                raw.extend(chunk)
                if len(raw) > MAX_BODY_BYTES:
                    reject(413, "BODY_LIMIT", "入力は8 MiB以内にしてください。")
        if len(raw) != length:
            raise ValueError("Incomplete body")
        payload = json.loads(
            raw,
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
            parse_float=finite_float,
        )
        if not isinstance(payload, dict):
            raise ValueError("Request must be an object")
    except ValueError, UnicodeDecodeError, RecursionError, TimeoutError, ClientDisconnect:
        reject(400, "INVALID_JSON", "JSONの型・重複キー・数値・本文を確認してください。")
    return payload


Payload = Annotated[dict, Depends(read_payload)]


def check_search_budget(payload):
    if isinstance(payload, dict):
        for field in ("solver", "diagnosis"):
            config = payload.get(field)
            if isinstance(config, dict):
                budget = config.get("time_limit_seconds")
                if isinstance(budget, (int, float)) and budget > MAX_SEARCH_SECONDS:
                    reject(400, "SEARCH_LIMIT", "探索予算は60秒以内にしてください。")


async def calculate(request: Request, work, status=200, locked=True):
    if locked and not request.app.state.solve_lock.acquire(blocking=False):
        return error(409, "BUSY", "計算中です。完了後に再実行してください。")
    try:
        # Keep the event loop responsive while the synchronous engine calculates.
        return JSONResponse(await run_in_threadpool(work), status_code=status)
    except StateError as failure:
        return JSONResponse(failure.body, status_code=failure.status)
    except InvalidOperation as failure:
        return error(400, "INVALID_OPERATION", str(failure)[:400])
    except Exception:
        return error(500, "ENGINE_ERROR", "計算処理が完了しませんでした。入力は保持しています。")
    finally:
        if locked:
            request.app.state.solve_lock.release()


@app.post(
    "/api/solve",
    operation_id="solve",
    summary="勤務計画を求解",
    responses=SEARCH_ERRORS,
    openapi_extra=post_contract(ref("EngineRequest"), ref("EngineResponse")),
)
async def solve_plan(request: Request, payload: Payload):
    check_search_budget(payload)
    return await calculate(request, lambda: solve(payload))


@app.post(
    "/api/compare",
    operation_id="compare",
    summary="同じ条件・探索予算で再計画を比較",
    responses=SEARCH_ERRORS,
    openapi_extra=post_contract(
        ref("CompareInput"), {"type": "array", "items": ref("ComparedPlan")}
    ),
)
async def compare_plans(request: Request, payload: Payload):
    check_search_budget(payload.get("request"))
    return await calculate(request, lambda: compare(payload))


@app.post(
    "/api/verify",
    operation_id="verify",
    summary="手修正した解を独立検証",
    responses=ERRORS,
    openapi_extra=post_contract(ref("VerifyInput"), ref("CheckedPlan")),
)
async def verify_plan(request: Request, payload: Payload):
    return await calculate(
        request, lambda: checked_plan(payload.get("request"), payload.get("solution"))
    )


@app.post(
    "/api/baseline",
    operation_id="baseline",
    summary="検証済み計画を基準スナップショットへ昇格",
    responses=ERRORS,
    openapi_extra=post_contract(ref("PlanSource"), ref("BaselineSnapshot")),
)
async def create_baseline(request: Request, payload: Payload):
    return await calculate(request, lambda: baseline_snapshot(payload))


@app.post(
    "/api/weeks",
    operation_id="weeks",
    summary="計画期間を月曜開始の週区間へ展開",
    responses={code: value for code, value in ERRORS.items() if code != 409},
    openapi_extra=post_contract(ref("WeekWindow"), {"type": "array", "items": ref("Interval")}),
)
def planning_weeks(payload: Payload):
    try:
        return weeks(payload)
    except InvalidOperation as failure:
        return error(400, "INVALID_OPERATION", str(failure)[:400])
    except Exception:
        return error(500, "ENGINE_ERROR", "週区間の展開が完了しませんでした。")


@app.post(
    "/api/restore",
    operation_id="restore",
    summary="保存ファイルの参照・版・解を再検証",
    responses=ERRORS,
    openapi_extra=post_contract(ref("Session"), ref("Session")),
)
async def restore_session(request: Request, payload: Payload):
    return await calculate(request, lambda: restore(payload, request.app.state.engine))


@app.post(
    "/api/parse",
    operation_id="parse",
    summary="JSONを厳密に読み直す（業務検証はしない）",
    responses={code: value for code, value in ERRORS.items() if code not in {409, 500}},
    openapi_extra=post_contract({"type": "object"}, {"type": "object"}),
)
async def parse_json(request: Request, payload: Payload):
    try:
        return JSONResponse(payload)
    except UnicodeEncodeError:
        return error(400, "INVALID_JSON", "JSONの文字列を確認してください。")


@app.exception_handler(StateError)
async def state_error(request: Request, failure: StateError):
    return JSONResponse(failure.body, status_code=failure.status)


def command_endpoint(operation):
    async def endpoint(request: Request, payload: Payload):
        store = request.app.state.store
        if operation in {"plans", "comparisons"}:
            check_search_budget(payload.get("request"))

        def work():
            if operation == "create":
                return commands.create(store, payload)
            if operation == "import":
                return commands.import_document(store, payload)
            return commands.execute(
                store,
                request.path_params["session_id"],
                operation,
                payload,
                request.path_params.get("plan_id"),
            )

        return await calculate(
            request,
            work,
            status=201
            if operation in {"create", "import", "plans", "comparisons", "edits"}
            else 200,
            locked=operation not in {"create", "draft", "delete"},
        )

    return endpoint


for operation, method, path, body in (
    ("create", "POST", "/api/sessions", "CreateSession"),
    ("import", "POST", "/api/sessions/import", "Session"),
    ("draft", "PUT", "/api/sessions/{session_id}/draft", "DraftCommand"),
    ("plans", "POST", "/api/sessions/{session_id}/plans", "PlanCommand"),
    ("comparisons", "POST", "/api/sessions/{session_id}/comparisons", "ComparisonCommand"),
    ("edits", "POST", "/api/sessions/{session_id}/plans/{plan_id}/edits", "EditCommand"),
    ("adopt", "POST", "/api/sessions/{session_id}/adopt", "AdoptCommand"),
    ("delete", "DELETE", "/api/sessions/{session_id}/plans/{plan_id}", "VersionCommand"),
):
    contract = post_contract(ref(body), ref("CommandReceipt"))
    contract["parameters"] = [
        {"name": part[1:-1], "in": "path", "required": True, "schema": {"type": "string"}}
        for part in path.split("/")
        if part.startswith("{")
    ]
    if operation in {"create", "import", "plans", "comparisons", "edits"}:
        contract["responses"]["201"] = contract["responses"].pop("200")
    app.add_api_route(
        path,
        command_endpoint(operation),
        methods=[method],
        operation_id=f"session_{operation}",
        responses=SEARCH_ERRORS if operation in {"plans", "comparisons"} else ERRORS,
        openapi_extra=contract,
    )


def query_endpoint(operation):
    def endpoint(request: Request):
        params = request.path_params
        state = request.app.state.store.read(params["session_id"])
        if operation == "session":
            return queries.session(state)
        if operation == "plans":
            return {
                **queries.envelope(state),
                "plans": [queries.summary(p) for p in state["plans"]],
            }
        if operation == "detail":
            return queries.detail(state, params["plan_id"])
        if operation == "monthly":
            return queries.monthly(state, params["plan_id"])
        if operation == "employee":
            return queries.employee(state, params["plan_id"], params["employee_id"])
        if operation == "comparisons":
            return queries.comparisons(state, request.query_params.getlist("plan_id"))
        if operation == "export":
            data = encode(queries.exported(state)).encode("utf-8")
            if len(data) > MAX_BODY_BYTES:
                raise StateError(
                    413,
                    "BODY_LIMIT",
                    "持ち出しJSONが8 MiBを超えています。不要な履歴を整理してください。",
                )
            return Response(
                data,
                media_type="application/json",
                headers={"Content-Disposition": 'attachment; filename="schedula-app.json"'},
            )
        return Response(
            queries.csv_export(state, params["kind"]),
            media_type="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{params["kind"]}.csv"'},
        )

    return endpoint


for operation, path, schema in (
    ("session", "/api/sessions/{session_id}", "SessionOverview"),
    ("plans", "/api/sessions/{session_id}/plans", "PlanList"),
    ("detail", "/api/sessions/{session_id}/plans/{plan_id}", "PlanDetail"),
    ("comparisons", "/api/sessions/{session_id}/comparisons", "ComparisonView"),
    ("monthly", "/api/sessions/{session_id}/plans/{plan_id}/monthly", "MonthlyView"),
    (
        "employee",
        "/api/sessions/{session_id}/plans/{plan_id}/employees/{employee_id}",
        "EmployeeView",
    ),
    ("export", "/api/sessions/{session_id}/export", "Session"),
    ("csv", "/api/sessions/{session_id}/exports/{kind}", None),
):
    app.add_api_route(
        path,
        query_endpoint(operation),
        methods=["GET"],
        operation_id=f"query_{operation}",
        responses={
            400: ERRORS[400],
            403: ERRORS[403],
            404: ERRORS[404],
            409: {**ERRORS[409], "description": "INVALID_STATE: 解のある検証済み計画が必要"},
            413: ERRORS[413],
            500: ERRORS[500],
        },
        openapi_extra={
            "parameters": [
                {
                    "name": part[1:-1],
                    "in": "path",
                    "required": True,
                    "schema": {"enum": ["monthly", "shifts", "demand"]}
                    if part == "{kind}"
                    else {"type": "string"},
                }
                for part in path.split("/")
                if part.startswith("{")
            ]
            + (
                [
                    {
                        "name": "plan_id",
                        "in": "query",
                        "required": True,
                        "schema": {
                            "type": "array",
                            "minItems": 1,
                            "maxItems": 2,
                            "uniqueItems": True,
                            "items": {"type": "string"},
                        },
                        "style": "form",
                        "explode": True,
                    }
                ]
                if operation == "comparisons"
                else []
            ),
            "responses": {
                "200": {
                    "description": "保存済み状態の読み取り",
                    "content": {
                        "text/csv" if schema is None else "application/json": {
                            "schema": {"type": "string"} if schema is None else ref(schema)
                        }
                    },
                }
            },
        },
    )
app.add_api_route(
    "/api/sessions/{session_id}/",
    query_endpoint("session"),
    methods=["GET"],
    include_in_schema=False,
)


@app.get("/", include_in_schema=False)
def index():
    path = ROOT / "front/dist/index.html"
    if not path.is_file():
        return error(503, "BUILD_REQUIRED", "画面をビルドしてください。")
    return FileResponse(path)


app.mount("/assets", StaticFiles(directory=ROOT / "front/dist/assets", check_dir=False))


def openapi():
    if app.openapi_schema is None:
        schema = get_openapi(title=app.title, version=app.version, routes=app.routes)
        schema.setdefault("components", {}).setdefault("schemas", {}).update(SCHEMAS)
        app.openapi_schema = schema
    return app.openapi_schema


app.openapi = openapi


def main():
    parser = argparse.ArgumentParser(description="schedula-app local server")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument(
        "--data-dir",
        required=True,
        type=Path,
        help="Customer-specific data directory outside the code/build tree",
    )
    parser.add_argument(
        "--dev", action="store_true", help="Allow the local Vite proxy on port 5173"
    )
    args = parser.parse_args()
    if args.data_dir.resolve().is_relative_to(ROOT):
        parser.error("保存先はコード・ビルド配置の外を指定してください。")
    app.state.data_dir = args.data_dir
    app.state.dev = args.dev
    with socket.create_server(("127.0.0.1", args.port)) as listener:
        app.state.url = f"http://127.0.0.1:{listener.getsockname()[1]}"
        config = uvicorn.Config(app, access_log=False, proxy_headers=False, timeout_keep_alive=10)
        try:
            uvicorn.Server(config).run(sockets=[listener])
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
