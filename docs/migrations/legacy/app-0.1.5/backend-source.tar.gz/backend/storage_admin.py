"""Consistent SQLite backup and verified restore into a new customer directory."""

import argparse
import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path

from queries import exported
from server import runtime
from store import DB_VERSION, StateError, Store, encode, pin
from workflow import InvalidOperation, restore


def backup(directory, output, engine):
    output = Path(output)
    if output.exists() or output.with_name(output.name + ".json").exists():
        raise ValueError("バックアップ先に既存ファイルがあります。別の名前を指定してください。")
    if not (Path(directory) / "sessions.sqlite3").is_file():
        raise ValueError("稼働する保存先がありません。")
    store = Store(directory, engine)
    store.backup(output)
    metadata = {
        "db_schema_version": DB_VERSION,
        "format": "schedula-app/1",
        "engine": pin(engine),
        "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
    }
    fd = os.open(
        output.with_name(output.name + ".json"), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600
    )
    with os.fdopen(fd, "w") as file:
        file.write(encode(metadata))
    return metadata


def restore_backup(source, destination, engine):
    source, destination = Path(source), Path(destination)
    if destination.exists():
        raise ValueError(
            "復元先は新しい保存ディレクトリを指定してください。既存原本は上書きしません。"
        )
    metadata = json.loads(source.with_name(source.name + ".json").read_text())
    with tempfile.TemporaryDirectory(prefix="schedula-restore-", dir=destination.parent) as stage:
        target = Path(stage) / "sessions.sqlite3"
        shutil.copyfile(source, target)
        expected = {
            "db_schema_version": DB_VERSION,
            "format": "schedula-app/1",
            "engine": pin(engine),
            "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        }
        if metadata != expected:
            raise ValueError("バックアップの固定情報・Schema・ハッシュが一致しません。")
        os.chmod(target, 0o600)
        store = Store(stage, engine)
        count = 0
        for session_id in store.session_ids():
            document = exported(store.read(session_id))
            restore(document, engine)  # All solutions and references; drafts stay unverified.
            count += len(document["plans"])
        destination.mkdir(
            mode=0o700
        )  # Exclusive creation after validation; never replace a live directory.
        try:
            os.rename(target, destination / "sessions.sqlite3")
        except OSError:
            destination.rmdir()
            raise
    return {
        "sessions": len(Store(destination, engine).session_ids()),
        "plans_rechecked": count,
        "engine": pin(engine),
        "db_schema_version": DB_VERSION,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="operation", required=True)
    save = sub.add_parser("backup")
    save.add_argument("--data-dir", type=Path, required=True)
    save.add_argument("--output", type=Path, required=True)
    load = sub.add_parser("restore")
    load.add_argument("--source", type=Path, required=True)
    load.add_argument("--destination", type=Path, required=True)
    args = parser.parse_args()
    try:
        engine = runtime()
        result = (
            backup(args.data_dir, args.output, engine)
            if args.operation == "backup"
            else restore_backup(args.source, args.destination, engine)
        )
    except OSError, ValueError, StateError, InvalidOperation:
        parser.exit(
            1, "保存・復元を完了できません。原本を保持して保存先・版・権限を確認してください。\n"
        )
    print(encode(result))  # Pins and counts only; no inputs, solutions or diagnostic text.


if __name__ == "__main__":
    main()
