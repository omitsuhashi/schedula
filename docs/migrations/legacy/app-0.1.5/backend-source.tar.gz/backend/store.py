"""Customer-local SQLite snapshots. Calculations never run inside a transaction."""

import json
import os
import sqlite3
import stat
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4

DB_VERSION = 1


class StateError(Exception):
    def __init__(self, status, code, message, **details):
        self.status = status
        self.body = {"error": code, "message": message, **details}


def pin(engine):
    return {key: engine[key] for key in ("version", "schema_version", "commit", "sha256")}


def encode(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":"))


def missing():
    raise StateError(404, "NOT_FOUND", "指定した保存済み状態はありません。")


def conflict(state, expected):
    if type(expected) is not int or expected < 0:
        raise StateError(400, "INVALID_OPERATION", "expected_versionは非負整数が必要です。")
    if state["version"] != expected:
        raise StateError(
            409,
            "VERSION_CONFLICT",
            "別の操作で更新されています。最新状態を確認してください。",
            current_version=state["version"],
        )


def plan_in(state, plan_id):
    for plan in state["plans"]:
        if plan["id"] == plan_id:
            return plan
    missing()


class Store:
    def __init__(self, directory, engine):
        directory = Path(directory)
        self.path = directory.resolve() / "sessions.sqlite3"
        self.engine = pin(engine)
        try:
            try:
                directory.mkdir(mode=0o700, parents=True)
            except FileExistsError:
                info = directory.lstat()
                if (
                    not stat.S_ISDIR(info.st_mode)
                    or info.st_uid != os.getuid()
                    or stat.S_IMODE(info.st_mode) != 0o700
                    or any(
                        entry.name
                        not in {
                            "sessions.sqlite3",
                            "sessions.sqlite3-journal",
                            "sessions.sqlite3-wal",
                            "sessions.sqlite3-shm",
                        }
                        or entry.is_symlink()
                        or not entry.is_file()
                        or entry.stat().st_nlink != 1
                        for entry in directory.iterdir()
                    )
                ):
                    raise StateError(
                        500,
                        "STORAGE_ERROR",
                        "保存先は実行ユーザー所有・権限700の専用ディレクトリが必要です。"
                        "新しい保存先を指定してください。",
                    ) from None
            fresh = not self.path.exists()
            if fresh:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
                os.close(fd)
            os.chmod(self.path, 0o600)
            with self.connection(write=True) as db:
                if fresh:
                    db.executescript("""
                        BEGIN IMMEDIATE;
                        CREATE TABLE metadata (engine TEXT NOT NULL);
                        CREATE TABLE sessions (
                            id TEXT PRIMARY KEY, version INTEGER NOT NULL CHECK(version >= 0),
                            input TEXT NOT NULL, selected TEXT, baseline TEXT, edit TEXT NOT NULL,
                            FOREIGN KEY(id, selected) REFERENCES plans(session_id, id)
                                DEFERRABLE INITIALLY DEFERRED,
                            FOREIGN KEY(id, baseline) REFERENCES plans(session_id, id)
                                DEFERRABLE INITIALLY DEFERRED
                        );
                        CREATE TABLE plans (
                            session_id TEXT NOT NULL REFERENCES sessions(id), id TEXT NOT NULL,
                            label TEXT NOT NULL, request TEXT NOT NULL, result TEXT NOT NULL,
                            evidence TEXT, PRIMARY KEY(session_id, id)
                        );
                        PRAGMA user_version = 1;
                    """)
                    db.execute("INSERT INTO metadata VALUES (?)", (encode(self.engine),))
                else:
                    if db.execute("PRAGMA user_version").fetchone()[0] != DB_VERSION:
                        raise StateError(409, "INCOMPATIBLE", "保存先のDB Schema版が一致しません。")
                    rows = db.execute("SELECT engine FROM metadata").fetchall()
                    if len(rows) != 1 or json.loads(rows[0][0]) != self.engine:
                        raise StateError(
                            409, "INCOMPATIBLE", "保存先のエンジン固定情報が一致しません。"
                        )
                    if (
                        db.execute("PRAGMA quick_check").fetchone()[0] != "ok"
                        or db.execute("PRAGMA foreign_key_check").fetchall()
                    ):
                        raise StateError(500, "STORAGE_ERROR", "保存先の整合性を確認できません。")
        except (OSError, ValueError) as failure:
            raise StateError(
                500, "STORAGE_ERROR", "保存先を開けません。原本は保持してください。"
            ) from failure

    @contextmanager
    def connection(self, write=False):
        db = None
        try:
            db = sqlite3.connect(
                self.path.as_uri() + ("?mode=rw" if write else "?mode=ro"), uri=True
            )
            db.execute("PRAGMA foreign_keys = ON")
            yield db
            if write:
                db.commit()
        except (sqlite3.Error, ValueError, OSError) as failure:
            raise StateError(
                500, "STORAGE_ERROR", "保存処理に失敗しました。現在の状態を確認してください。"
            ) from failure
        finally:
            if db is not None:
                db.close()

    def read(self, session_id, db=None):
        if db is None:
            with self.connection() as connection:
                connection.execute("BEGIN")
                return self.read(session_id, connection)
        row = db.execute(
            "SELECT version,input,selected,baseline,edit FROM sessions WHERE id=?", (session_id,)
        ).fetchone()
        if row is None:
            missing()
        plans = []
        for plan_id, label, request, result, evidence in db.execute(
            "SELECT id,label,request,result,evidence FROM plans WHERE session_id=? ORDER BY rowid",
            (session_id,),
        ):
            plan = {
                "id": plan_id,
                "label": label,
                "request": json.loads(request),
                "result": json.loads(result),
            }
            if evidence is not None:
                plan["evidence"] = json.loads(evidence)
            plans.append(plan)
        return {
            "session_id": session_id,
            "version": row[0],
            "format": "schedula-app/1",
            "engine": dict(self.engine),
            "input": row[1],
            "selected": row[2],
            "baseline": row[3],
            "edit": json.loads(row[4]),
            "plans": plans,
        }

    def insert_plans(self, db, session_id, plans):
        for plan in plans:
            db.execute(
                "INSERT INTO plans VALUES (?,?,?,?,?,?)",
                (
                    session_id,
                    plan["id"],
                    plan["label"],
                    encode(plan["request"]),
                    encode(plan["result"]),
                    encode(plan["evidence"]) if "evidence" in plan else None,
                ),
            )

    def create(self, document):
        session_id = str(uuid4())
        with self.connection(write=True) as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute(
                "INSERT INTO sessions VALUES (?,0,?,?,?,?)",
                (
                    session_id,
                    document["input"],
                    document.get("selected"),
                    document.get("baseline"),
                    encode(document.get("edit")),
                ),
            )
            self.insert_plans(db, session_id, document.get("plans", []))
        return session_id

    def update(self, state, expected, additions=(), deletions=()):
        with self.connection(write=True) as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT version FROM sessions WHERE id=?", (state["session_id"],)
            ).fetchone()
            if row is None:
                missing()
            conflict({"version": row[0]}, expected)
            existing = {
                row[0]
                for row in db.execute(
                    "SELECT id FROM plans WHERE session_id=?", (state["session_id"],)
                )
            }
            ids = existing | {p["id"] for p in additions}
            ids -= set(deletions)
            if any(
                state[key] is not None and state[key] not in ids for key in ("selected", "baseline")
            ):
                raise StateError(409, "INVALID_STATE", "採用案・基準計画の参照が不正です。")
            self.insert_plans(db, state["session_id"], additions)
            for plan_id in deletions:
                if plan_id not in existing:
                    missing()
                db.execute(
                    "DELETE FROM plans WHERE session_id=? AND id=?", (state["session_id"], plan_id)
                )
            db.execute(
                "UPDATE sessions SET version=version+1,input=?,selected=?,baseline=?,edit=? "
                "WHERE id=?",
                (
                    state["input"],
                    state["selected"],
                    state["baseline"],
                    encode(state["edit"]),
                    state["session_id"],
                ),
            )
        return expected + 1

    def session_ids(self):
        with self.connection() as db:
            return [row[0] for row in db.execute("SELECT id FROM sessions ORDER BY rowid")]

    def backup(self, destination):
        destination = Path(destination)
        fd = os.open(destination, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        with self.connection() as source, sqlite3.connect(destination) as target:
            source.backup(target)
