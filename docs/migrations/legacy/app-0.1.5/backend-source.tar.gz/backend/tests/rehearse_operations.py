"""Disposable deployments, real SSH access, backups, restore and release switching."""

import argparse
import copy
import getpass
import hashlib
import io
import json
import os
import platform
import shutil
import signal
import socket
import subprocess
import tarfile
import tempfile
import time
from contextlib import ExitStack, contextmanager
from datetime import UTC, datetime
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[2]


def run(*command, cwd=None, check=True):
    return subprocess.run(
        command, cwd=cwd, capture_output=True, text=True, check=check, timeout=300
    )


def port():
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        return listener.getsockname()[1]


@contextmanager
def process(command, log):
    with log.open("wb") as output:
        child = subprocess.Popen(command, stdout=output, stderr=output, start_new_session=True)
        try:
            yield child
        finally:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGTERM)
                child.wait(timeout=10)


def deploy(revision, target):
    commit = run("git", "rev-parse", "--verify", f"{revision}^{{commit}}", cwd=ROOT).stdout.strip()
    archive = subprocess.run(
        ["git", "archive", commit], cwd=ROOT, capture_output=True, check=True
    ).stdout
    target.mkdir(mode=0o700)
    with tarfile.open(fileobj=io.BytesIO(archive)) as source:
        source.extractall(target, filter="data")
    run("uv", "sync", "--project", str(target / "backend"), "--locked", "--no-dev")
    run("pnpm", "--dir", str(target / "front"), "install", "--frozen-lockfile")
    run("pnpm", "--dir", str(target / "front"), "run", "build")
    print(f"Installed independent release {commit}", flush=True)
    return commit


def http(local_port, server_port, path, body=None):
    # Separate hosts use the same local/remote port in production. This same-host
    # rehearsal needs a free tunnel port, so preserve the app's expected Host.
    headers = {"Host": f"127.0.0.1:{server_port}"}
    data = None
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
        headers["Origin"] = f"http://127.0.0.1:{server_port}"
    request = Request(f"http://127.0.0.1:{local_port}{path}", data=data, headers=headers)
    with urlopen(request, timeout=60) as response:
        return json.load(response)


def wait_http(local_port, server_port):
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        try:
            return http(local_port, server_port, "/api/runtime")
        except OSError:
            time.sleep(0.1)
    raise RuntimeError("App or SSH tunnel did not start")


def ssh_config(directory, app_port):
    directory.mkdir(mode=0o700)
    for name in ("host", "client"):
        run("ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-f", str(directory / name))
    authorized = directory / "authorized_keys"
    authorized.write_text((directory / "client.pub").read_text())
    authorized.chmod(0o600)
    ssh_port = port()
    (directory / "known_hosts").write_text(
        f"[127.0.0.1]:{ssh_port} " + (directory / "host.pub").read_text()
    )
    (directory / "config").write_text(
        f"""Port {ssh_port}
ListenAddress 127.0.0.1
HostKey {directory}/host
PidFile {directory}/pid
AuthorizedKeysFile {authorized}
StrictModes yes
AllowUsers {getpass.getuser()}
AuthenticationMethods publickey
PasswordAuthentication no
KbdInteractiveAuthentication no
UsePAM no
AllowTcpForwarding local
AllowStreamLocalForwarding no
PermitOpen 127.0.0.1:{app_port}
PermitListen none
AllowAgentForwarding no
X11Forwarding no
PermitTTY no
ForceCommand /usr/bin/false
"""
    )
    command = [
        "ssh",
        "-F",
        "/dev/null",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "IdentitiesOnly=yes",
        "-o",
        "StrictHostKeyChecking=yes",
        "-o",
        f"UserKnownHostsFile={directory}/known_hosts",
        "-o",
        "ConnectTimeout=3",
        "-o",
        "ConnectionAttempts=1",
        "-i",
        str(directory / "client"),
        "-p",
        str(ssh_port),
    ]
    return command, f"{getpass.getuser()}@127.0.0.1"


def target_supports_store(active):
    return (active / "backend/store.py").exists()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--previous", default="41ffe8ee7c5c66ee89d1b8cf570f259390839397")
    parser.add_argument("--current", default="HEAD")
    args = parser.parse_args()
    sshd = shutil.which("sshd") or "/usr/sbin/sshd"
    results = ROOT / "test-results"
    results.mkdir(exist_ok=True)
    started = time.monotonic()
    record = {"at": datetime.now(UTC).isoformat(), "os": platform.system(), "checks": []}
    with tempfile.TemporaryDirectory(prefix="operations-", dir=results) as temporary:
        base = Path(temporary).resolve()
        previous, current = base / "previous", base / "current-release"
        record["previous_app_commit"] = deploy(args.previous, previous)
        record["current_app_commit"] = deploy(args.current, current)
        active = base / "active"
        active.symlink_to(previous)
        app_port = port()
        command, host = ssh_config(base / "alpha-ssh", app_port)
        beta_command, beta_host = ssh_config(base / "beta-ssh", port())
        alpha, beta, backup, recovered = [
            base / name for name in ("alpha", "beta", "backup", "recovered")
        ]
        for directory in (alpha, beta, backup, recovered):
            directory.mkdir(mode=0o700)
        (beta / "session.json").write_text('{"fictional_customer":"beta"}')
        beta_bytes = (beta / "session.json").read_bytes()
        with ExitStack() as stack:
            stack.enter_context(
                process(
                    [sshd, "-D", "-e", "-f", str(base / "alpha-ssh/config")], base / "alpha-ssh.log"
                )
            )
            stack.enter_context(
                process(
                    [sshd, "-D", "-e", "-f", str(base / "beta-ssh/config")], base / "beta-ssh.log"
                )
            )
            with process(
                [
                    str(active / "backend/.venv/bin/python"),
                    str(active / "backend/server.py"),
                    *(
                        ["--data-dir", str(base / "app-data")]
                        if target_supports_store(active)
                        else []
                    ),
                    "--port",
                    str(app_port),
                ],
                base / "previous.log",
            ):
                engine = wait_http(app_port, app_port)
                local_port = port()
                with process(
                    command + ["-N", "-L", f"127.0.0.1:{local_port}:127.0.0.1:{app_port}", host],
                    base / "tunnel.log",
                ):
                    wait_http(local_port, app_port)
                    request = http(local_port, app_port, "/api/examples/replan")
                    pair = http(
                        local_port,
                        app_port,
                        "/api/compare",
                        {"request": request, "modes": ["preserve_assigned", "rebuild"]},
                    )
                    assert [p["result"]["status"] for p in pair] == ["PARTIAL", "OPTIMAL"]
                    document = {
                        "format": "schedula-app/1",
                        "engine": {
                            key: engine[key]
                            for key in ("version", "schema_version", "commit", "sha256")
                        },
                        "input": json.dumps(request),
                        "plans": [
                            {
                                "id": p["mode"],
                                "label": p["mode"],
                                "request": p["request"],
                                "result": p["result"],
                            }
                            for p in pair
                        ],
                        "selected": "rebuild",
                        "baseline": "preserve_assigned",
                        "edit": None,
                    }
                    http(local_port, app_port, "/api/restore", document)
                record["checks"].append(
                    "SSH key allowed; real compare and restore over encrypted tunnel"
                )
                assert run(*command, host, "true", check=False).returncode != 0
                refused_target = run(*command, "-W", "127.0.0.1:1", host, check=False)
                assert "administratively prohibited" in refused_target.stderr
                wrong_key = beta_command.copy()
                wrong_key[wrong_key.index("-i") + 1] = str(base / "alpha-ssh/client")
                assert run(*wrong_key, beta_host, "true", check=False).returncode != 0
                assert "Permission denied" in run(*wrong_key, beta_host, "true", check=False).stderr
                (base / "alpha-ssh/authorized_keys").write_text("")
                assert "Permission denied" in run(*command, host, "true", check=False).stderr
                record["checks"].append(
                    "Shell, other destination, other customer's key and revoked key denied"
                )
                raw = json.dumps(document, ensure_ascii=False).encode()
                (alpha / "session.json").write_bytes(raw)
                (alpha / "session.json").chmod(0o600)
                shutil.copy2(alpha / "session.json", backup / "session.json")
                digest = hashlib.sha256(raw).hexdigest()
                record["saved_sha256"] = digest
                record["engine"] = document["engine"]
                (backup / "release.json").write_text(
                    json.dumps(
                        {
                            "customer": "fictional-alpha",
                            "app_commit": record["previous_app_commit"],
                            "engine": document["engine"],
                            "saved_sha256": digest,
                        }
                    )
                )
                (alpha / "session.json").unlink()  # Simulated loss after verified backup.
            shutil.copy2(backup / "session.json", recovered / "session.json")
            assert hashlib.sha256((recovered / "session.json").read_bytes()).hexdigest() == digest
            recovered_document = json.loads((recovered / "session.json").read_text())
            record["checks"].append(
                "Saved file and version record backed up; "
                "source loss recovered into separate deployment"
            )
            for target, label in ((current, "update"), (previous, "rollback")):
                next_link = base / "next"
                next_link.symlink_to(target)
                os.replace(next_link, active)
                with process(
                    [
                        str(active / "backend/.venv/bin/python"),
                        str(active / "backend/server.py"),
                        *(
                            ["--data-dir", str(base / "app-data")]
                            if target_supports_store(active)
                            else []
                        ),
                        "--port",
                        str(app_port),
                    ],
                    base / f"{label}.log",
                ):
                    next_engine = wait_http(app_port, app_port)
                    target_document = recovered_document
                    target_file = recovered / "session.json"
                    if next_engine["sha256"] != engine["sha256"]:
                        try:
                            http(app_port, app_port, "/api/restore", recovered_document)
                        except HTTPError as failure:
                            assert failure.code == 400
                        else:
                            raise AssertionError("Incompatible engine file was accepted")
                        next_request = http(app_port, app_port, "/api/examples/replan")
                        next_pair = http(
                            app_port,
                            app_port,
                            "/api/compare",
                            {"request": next_request, "modes": ["preserve_assigned", "rebuild"]},
                        )
                        assert [p["result"]["status"] for p in next_pair] == ["PARTIAL", "OPTIMAL"]
                        target_document = copy.deepcopy(document)
                        target_document["engine"] = {
                            key: next_engine[key]
                            for key in ("version", "schema_version", "commit", "sha256")
                        }
                        target_document["input"] = json.dumps(next_request, ensure_ascii=False)
                        for plan, outcome in zip(target_document["plans"], next_pair, strict=True):
                            plan.update(request=outcome["request"], result=outcome["result"])
                        target_file = recovered / "current-session.json"
                        target_file.write_text(json.dumps(target_document, ensure_ascii=False))
                        target_file.chmod(0o600)
                        shutil.copy2(target_file, backup / "current-session.json")
                        target_file.unlink()
                        shutil.copy2(backup / "current-session.json", target_file)
                        assert (
                            target_file.read_bytes()
                            == (backup / "current-session.json").read_bytes()
                        )
                        record["checks"].append(
                            "Incompatible update rejected old file; new plan saved separately"
                        )
                    if label == "update":
                        record["current_engine"] = target_document["engine"]
                    restored = http(
                        app_port, app_port, "/api/restore", json.loads(target_file.read_text())
                    )
                    for key in ("input", "selected", "baseline"):
                        assert restored[key] == target_document[key]
                    for original, plan in zip(
                        target_document["plans"], restored["plans"], strict=True
                    ):
                        assert plan["request"] == original["request"]
                        assert plan["result"]["solution"] == original["result"]["solution"]
                        assert plan["result"]["verification"]["valid"] is True
                    if label == "update" and target_supports_store(active):
                        # Re-authorize this disposable fixture key after the revocation check.
                        (base / "alpha-ssh/authorized_keys").write_text(
                            (base / "alpha-ssh/client.pub").read_text()
                        )
                        with process(
                            command
                            + ["-N", "-L", f"127.0.0.1:{local_port}:127.0.0.1:{app_port}", host],
                            base / "new-api-tunnel.log",
                        ):
                            wait_http(local_port, app_port)
                            imported = http(
                                local_port, app_port, "/api/sessions/import", target_document
                            )
                            session_path = f"/api/sessions/{imported['session_id']}"
                            saved = http(local_port, app_port, session_path)
                            assert saved["selected"] == target_document["selected"]
                            target_document = http(local_port, app_port, session_path + "/export")
                            target_file.write_text(json.dumps(target_document, ensure_ascii=False))
                            recovered_document = target_document
                            run(
                                str(current / "backend/.venv/bin/python"),
                                str(current / "backend/storage_admin.py"),
                                "backup",
                                "--data-dir",
                                str(base / "app-data"),
                                "--output",
                                str(backup / "sessions.sqlite3"),
                            )
                        record["checks"].append(
                            "SSH: new session import/Query/export and consistent SQLite backup"
                        )
                    if label == "update":
                        checked = run(
                            str(current / "backend/.venv/bin/python"),
                            str(current / "backend/check_saved.py"),
                            str(target_file),
                        )
                        assert json.loads(checked.stdout)["plans"] == 2
                        bad = copy.deepcopy(target_document)
                        bad["plans"][0]["result"]["solution"]["assignments"] *= 2
                        (recovered / "invalid.json").write_text(json.dumps(bad))
                        refused = run(
                            str(current / "backend/.venv/bin/python"),
                            str(current / "backend/check_saved.py"),
                            str(recovered / "invalid.json"),
                            check=False,
                        )
                        assert refused.returncode == 1 and not refused.stdout
                        assert "alice" not in refused.stderr
                        incompatible = copy.deepcopy(target_document)
                        incompatible["engine"]["schema_version"] = "unknown"
                        (recovered / "invalid.json").write_text(json.dumps(incompatible))
                        assert (
                            run(
                                str(current / "backend/.venv/bin/python"),
                                str(current / "backend/check_saved.py"),
                                str(recovered / "invalid.json"),
                                check=False,
                            ).returncode
                            == 1
                        )
                record["checks"].append(
                    f"{label}: input, comparison baseline and both solutions independently verified"
                )
            assert (beta / "session.json").read_bytes() == beta_bytes
            assert (backup / "session.json").read_bytes() == raw
            assert shutil.disk_usage(base).free > 0
            record["checks"].append(
                "Other customer's storage untouched; invalid plan/version rejected; "
                "capacity readable"
            )
        record["elapsed_seconds"] = round(time.monotonic() - started, 2)
        record["limits"] = (
            "Synthetic data on one host, two independent source archives and venvs; "
            "Files reverified under their matching engine/schema; incompatible updates "
            "use separate new plans, rollback uses the previous file. "
            "Not customer production or cross-host disaster recovery."
        )
    (results / "customer-operations.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2), flush=True)


if __name__ == "__main__":
    main()
