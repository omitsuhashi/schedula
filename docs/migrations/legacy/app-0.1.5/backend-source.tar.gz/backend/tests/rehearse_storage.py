"""Real HTTP restart, customer isolation and SQLite backup/restore rehearsal."""

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from rehearse_operations import ROOT, http, port, process, wait_http


def main():
    result = {"at": datetime.now(UTC).isoformat(), "checks": []}
    with tempfile.TemporaryDirectory(prefix="schedula-storage-") as temporary:
        base = Path(temporary)
        a, b, recovered = base / "customer-a", base / "customer-b", base / "recovered-a"
        pa, pb = port(), port()

        def server(directory, number, name):
            return process(
                [
                    sys.executable,
                    str(ROOT / "backend/server.py"),
                    "--port",
                    str(number),
                    "--data-dir",
                    str(directory),
                ],
                base / f"{name}.log",
            )

        def admin(*args):
            run = subprocess.run(
                [sys.executable, str(ROOT / "backend/storage_admin.py"), *map(str, args)],
                capture_output=True,
                text=True,
                timeout=30,
            )
            assert run.returncode == 0, run.stderr
            return json.loads(run.stdout)

        with server(b, pb, "b"):
            engine = wait_http(pb, pb)
            bid = http(pb, pb, "/api/sessions", {"input": "customer B draft"})["session_id"]
            before_b = http(pb, pb, f"/api/sessions/{bid}")
            with server(a, pa, "a"):
                wait_http(pa, pa)
                sid = http(pa, pa, "/api/sessions", {"input": "{unfinished"})["session_id"]
                path = f"/api/sessions/{sid}"
                payload = http(pa, pa, "/api/examples/partial")
                made = http(pa, pa, path + "/plans", {"expected_version": 0, "request": payload})
                pid = made["plan_ids"][0]
                adopted = http(pa, pa, path + "/adopt", {"expected_version": 1, "plan_id": pid})
                assert adopted["result"] == {"status": "PARTIAL", "demand_satisfied": False}
                req = http(pa, pa, "/api/examples/replan")
                compared = http(
                    pa,
                    pa,
                    path + "/comparisons",
                    {
                        "expected_version": 2,
                        "request": req,
                        "modes": ["preserve_assigned", "rebuild"],
                    },
                )
                assert compared["result"]["statuses"] == ["PARTIAL", "OPTIMAL"]
                before = http(pa, pa, path + "/export")
                snapshot = base / "a-backup.sqlite3"
                admin("backup", "--data-dir", a, "--output", snapshot)
                result["checks"].append(
                    "live HTTP customer A: PARTIAL adoption, two plans, consistent backup"
                )
            shutil.rmtree(a)  # Original loss after completed backup, while B remains live.
            verified = admin("restore", "--source", snapshot, "--destination", recovered)
            assert verified["sessions"] == 1 and verified["plans_rechecked"] == 3
            with server(recovered, pa, "a-restored"):
                wait_http(pa, pa)
                assert http(pa, pa, path + "/export") == before
                assert http(pa, pa, path)["version"] == 3
                document = base / "compatible.json"
                document.write_text(json.dumps(before))
                checked = subprocess.run(
                    [sys.executable, str(ROOT / "backend/check_saved.py"), str(document)],
                    capture_output=True,
                    text=True,
                )
                assert checked.returncode == 0
                result["checks"].append(
                    "source loss: separate restore, all plans verified, "
                    "HTTP resume and compatible JSON checked"
                )
            # Same DB Schema/pin: restart after restoring; Query keeps the saved values.
            with server(recovered, pa, "a-restarted"):
                wait_http(pa, pa)
                assert http(pa, pa, path + "/export") == before
            assert http(pb, pb, f"/api/sessions/{bid}") == before_b
            result["checks"].append(
                "current release restart preserves version; customer B unchanged"
            )
            bad = base / "corrupt.sqlite3"
            shutil.copyfile(snapshot, bad)
            shutil.copyfile(
                snapshot.with_name(snapshot.name + ".json"), bad.with_name(bad.name + ".json")
            )
            bad.write_bytes(b"broken")
            failed = subprocess.run(
                [
                    sys.executable,
                    str(ROOT / "backend/storage_admin.py"),
                    "restore",
                    "--source",
                    str(bad),
                    "--destination",
                    str(base / "bad-restore"),
                ],
                capture_output=True,
                text=True,
            )
            assert failed.returncode != 0 and not (base / "bad-restore").exists()
            assert "broken" not in failed.stderr
            result["checks"].append(
                "corrupt backup rejected without destination or live-data overwrite"
            )
            result["backup_sha256"] = hashlib.sha256(snapshot.read_bytes()).hexdigest()
            result["engine"] = engine
            assert all(
                "source_request" not in log.read_text() and "source_solution" not in log.read_text()
                for log in base.glob("*.log")
            )
            result["checks"].append(
                "operational logs contain no request, solution or diagnostic body"
            )
    output = ROOT / "test-results/storage-operations.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print("SQLite / real HTTP / customer isolation / backup / verified restore / restart: OK")


if __name__ == "__main__":
    main()
