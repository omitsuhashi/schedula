import copy
import hashlib
import json
import subprocess
import sys
import threading
from pathlib import Path

import pytest
from fastapi.openapi.models import OpenAPI
from fastapi.testclient import TestClient
from jsonschema import validate
from shift_schedula import get_schema, solve

import server


@pytest.fixture
def app(tmp_path):
    server.app.state.data_dir = tmp_path / "data"
    with TestClient(server.app, base_url="http://127.0.0.1:8765") as client:
        yield client


def request(app, path, body=None, headers=None):
    response = app.request(
        "GET" if body is None else "POST",
        path,
        content=body,
        headers=headers or ({"Content-Type": "application/json"} if body is not None else {}),
    )
    return response.status_code, response.json()


@pytest.mark.parametrize(
    "example,status,shortage", [("complete", "OPTIMAL", 0), ("partial", "PARTIAL", 30)]
)
def test_installed_engine_over_http(app, example, status, shortage):
    code, payload = request(app, f"/api/examples/{example}")
    assert code == 200
    code, result = request(app, "/api/solve", json.dumps(payload))
    assert code == 200
    assert result["status"] == status
    assert result["verification"]["valid"] is True
    assert result["shortage_summary"]["total_person_minutes"] == shortage
    assert result["solver"]["engine_version"] == "0.1.5"
    assert result["schema_version"] == "0.10"
    # The calculation imports the installed wheel, never a sibling source checkout.
    import shift_schedula

    assert "site-packages" in str(Path(shift_schedula.__file__).resolve())


def test_pin_and_schema(app):
    code, engine = request(app, "/api/runtime")
    assert code == 200
    assert engine["commit"] == "fd8c140ff0dae8c8cefa82b5d3857ec0e0e90eaf"
    wheel = server.ROOT / "vendor/schedula" / engine["wheel"]
    assert hashlib.sha256(wheel.read_bytes()).hexdigest() == engine["sha256"]
    assert request(app, "/api/schema/request")[1] == get_schema("request", "0.10")


@pytest.mark.parametrize(
    "name,status,summary",
    [
        ("demand_priority", "PARTIAL", "priority_summary"),
        ("continuity_month", "OPTIMAL", "continuity_summary"),
        ("continuity_replan", "OPTIMAL", "change_summary"),
        ("scheduled_cost", "OPTIMAL", "cost_summary"),
        ("duty_balance", "OPTIMAL", "duty_balance_summary"),
        ("continuity_duty_balance", "OPTIMAL", "duty_balance_summary"),
    ],
)
def test_latest_features_survive_verification_and_restore(app, name, status, summary):
    code, payload = request(app, f"/api/examples/{name}")
    assert code == 200 and payload["schema_version"] == "0.10"
    code, result = request(app, "/api/solve", json.dumps(payload))
    assert code == 200 and result["status"] == status
    validate(result, get_schema("response", "0.10"))
    assert result[summary]
    document = saved_document(app.app.state.engine, payload, result)
    code, restored = request(app, "/api/restore", json.dumps(document))
    assert code == 200
    checked = restored["plans"][0]["result"]
    assert checked["verification"]["valid"] is True
    assert checked["solution"] == result["solution"]
    assert all(not o["proven_optimal"] for o in checked["objectives"])
    assert all(not g["proven_minimal"] for g in checked["priority_summary"]["groups"])
    for field in ("cost_summary", "duty_balance_summary", "continuity_summary", "change_summary"):
        assert checked[field] == result[field]
    code, baseline = request(
        app,
        "/api/baseline",
        json.dumps({"id": "latest", "request": payload, "solution": checked["solution"]}),
    )
    assert code == 200 and baseline["source_request"]["schema_version"] == "0.10"


def test_conflict_refinement_keeps_original_infeasible_result(app):
    code, result = request(app, "/api/solve", json.dumps(example("conflict_refinement")))
    assert code == 200 and result["status"] == "INFEASIBLE"
    assert result["solution"] is None
    validate(result, get_schema("response", "0.10"))
    conflict = result["diagnosis_result"]["conflict"]
    assert conflict["infeasibility_proven"] is True
    assert conflict["minimality"] == "inclusion_minimal"
    assert {c["json_pointer"] for c in conflict["conditions"]} == {
        "/constraints/0",
        "/constraints/1",
    }


def test_openapi_describes_live_api(app):
    code, document = request(app, "/openapi.json")
    assert code == 200 and document["openapi"].startswith("3.1.")
    OpenAPI.model_validate(document)
    ids = []
    for name in ("solve", "compare", "verify", "baseline", "weeks", "restore", "parse"):
        operation = document["paths"][f"/api/{name}"]["post"]
        ids.append(operation["operationId"])
        assert operation["requestBody"]["required"] is True
        assert operation["requestBody"]["content"]["application/json"]["schema"]
        assert operation["responses"]["200"]["content"]["application/json"]["schema"]
        expected = {"400", "403", "413", "415"}
        if name not in {"parse", "weeks"}:
            expected.add("409")
        else:
            assert "409" not in operation["responses"]
        if name != "parse":
            expected.add("500")
        assert expected <= set(operation["responses"])
        assert ("SEARCH_LIMIT" in operation["responses"]["400"]["description"]) == (
            name in {"solve", "compare"}
        )
        # Invalid business input is an engine diagnostic, not Pydantic coercion/422.
        assert "422" not in operation["responses"]
    assert len(set(ids)) == len(ids)

    def resolve_references(node):
        if isinstance(node, list):
            for value in node:
                resolve_references(value)
        elif isinstance(node, dict):
            if "$ref" in node:
                reference = node["$ref"]
                assert reference.startswith("#/")
                target = document
                for key in reference[2:].split("/"):
                    target = target[key.replace("~1", "/").replace("~0", "~")]
                assert isinstance(target, dict)
            for value in node.values():
                resolve_references(value)

    resolve_references(document)
    for kind in ("request", "response", "solution", "verification"):
        code, schema = request(app, f"/api/schema/{kind}")
        assert code == 200 and schema == get_schema(kind, "0.10")
    assert request(app, "/api/schema/unknown")[0] == 404
    assert request(app, "/api/examples/unknown")[0] == 404
    runtime_fields = document["components"]["schemas"]["Runtime"]["required"]
    assert set(runtime_fields) <= set(request(app, "/api/runtime")[1])


def test_invalid_input_is_not_a_plan(app):
    _, result = request(app, "/api/solve", '{"schema_version":"0.10"}')
    assert result["status"] == "INVALID_INPUT"
    assert result["solution"] is None
    assert result["diagnostics"]


@pytest.mark.parametrize(
    "body", ["[]", '{"x":1,"x":2}', '{"x":NaN}', "{", '{"x":Infinity}', '{"x":1e999}']
)
def test_json_boundary(app, body):
    code, result = request(app, "/api/solve", body)
    assert code == 400
    assert result["error"] == "INVALID_JSON"


@pytest.mark.parametrize(
    "body",
    [
        r'{"x":"\ud800"}',
        r'{"x":"\udfff"}',
        r'{"\ud800":"x"}',
        r'{"x":[{"y":"\udfff"}]}',
    ],
)
def test_parse_rejects_unpaired_surrogates_without_calculation_lock(app, body):
    with app.app.state.solve_lock:
        code, result = request(app, "/api/parse", body)
    assert code == 400 and result["error"] == "INVALID_JSON"


@pytest.mark.parametrize("body", [r'{"x":"\ud83d\ude00"}', '{"勤務":"😀"}'])
def test_parse_preserves_valid_unicode_without_calculation_lock(app, body):
    with app.app.state.solve_lock:
        assert request(app, "/api/parse", body) == (200, json.loads(body))


def test_http_boundary(app):
    assert request(app, "/api/runtime", headers={"Host": "evil.example"})[0] == 403
    assert (
        request(
            app,
            "/api/solve",
            "{}",
            {"Origin": "https://evil.example", "Content-Type": "application/json"},
        )[0]
        == 403
    )
    assert request(app, "/api/solve", "{}", {"Content-Type": "text/plain"})[0] == 415
    assert (
        request(
            app,
            "/api/solve",
            "{}",
            {"Content-Type": "application/json", "Content-Length": str(server.MAX_BODY_BYTES + 1)},
        )[0]
        == 413
    )
    assert request(app, "/api/solve", '{"solver":{"time_limit_seconds":61}}')[0] == 400
    assert request(app, "/../backend/server.py")[0] == 404


def test_one_calculation_at_a_time(app):
    with app.app.state.solve_lock:
        assert request(app, "/api/solve", "{}")[0] == 409
    assert request(app, "/api/solve", "{}")[0] == 200


def test_calculation_keeps_api_responsive(app, monkeypatch):
    entered = threading.Event()
    release = threading.Event()

    def slow_solve(payload):
        entered.set()
        assert release.wait(timeout=10)
        return {"status": "test"}

    monkeypatch.setattr(server, "solve", slow_solve)
    results = []
    thread = threading.Thread(target=lambda: results.append(request(app, "/api/solve", "{}")))
    thread.start()
    try:
        assert entered.wait(timeout=5)
        assert request(app, "/api/runtime")[0] == 200
        payload = {"solver": {"time_limit_seconds": 61}}
        assert request(app, "/api/parse", json.dumps(payload)) == (200, payload)
        window = example("complete")["planning_window"]
        assert request(app, "/api/weeks", json.dumps(window))[0] == 200
        for path in ("solve", "compare", "verify", "baseline", "restore"):
            assert request(app, f"/api/{path}", "{}")[1]["error"] == "BUSY"
    finally:
        release.set()
        thread.join(timeout=10)
    assert results == [(200, {"status": "test"})]


def test_vite_proxy_requires_dev_mode(app, monkeypatch):
    headers = {"Host": "127.0.0.1:5173", "Origin": "http://127.0.0.1:5173"}
    assert request(app, "/api/runtime", headers=headers)[0] == 403
    monkeypatch.setattr(server.app.state, "dev", True)
    assert request(app, "/api/runtime", headers=headers)[0] == 200
    headers["Origin"] = "https://evil.example"
    assert request(app, "/api/runtime", headers=headers)[0] == 403


def test_security_headers_and_static_boundary(app):
    response = app.get("/api/runtime")
    assert response.headers["x-content-type-options"] == "nosniff"
    assert "script-src 'self'" in response.headers["content-security-policy"]
    assert app.get("/assets/../../backend/server.py").status_code == 404


def test_engine_failure_is_http_failure(app, monkeypatch):
    def fail(payload):
        raise RuntimeError("private input must not be returned")

    monkeypatch.setattr(server, "solve", fail)
    code, result = request(app, "/api/solve", "{}")
    assert code == 500
    assert result["error"] == "ENGINE_ERROR"
    assert "private input" not in json.dumps(result)


@pytest.mark.parametrize(
    "headers,error",
    [
        ({"Content-Length": "-1"}, "INVALID_LENGTH"),
        ({"Content-Length": "3"}, "INVALID_JSON"),
        ({"Transfer-Encoding": "chunked"}, "INVALID_LENGTH"),
        ({"Content-Length": "8388609"}, "BODY_LIMIT"),
    ],
)
def test_light_route_preserves_length_checks(app, headers, error):
    code, result = request(app, "/api/parse", "{}", {"Content-Type": "application/json", **headers})
    assert code in {400, 413} and result["error"] == error


def test_cp_sat_dependency_missing():
    payload = json.loads((server.ROOT / "backend/examples/complete.json").read_text())
    command = """
import json, sys
sys.modules['ortools'] = None
from shift_schedula import solve
print(json.dumps(solve(json.loads(sys.stdin.read()))))
"""
    process = subprocess.run(
        [sys.executable, "-c", command],
        input=json.dumps(payload),
        text=True,
        capture_output=True,
        check=True,
    )
    result = json.loads(process.stdout)
    assert result["status"] == "BACKEND_UNAVAILABLE"
    assert result["solution"] is None


def test_unsatisfiable_hard_bound_is_not_partial():
    payload = json.loads((server.ROOT / "backend/examples/complete.json").read_text())
    impossible = copy.deepcopy(payload)
    impossible["constraints"][0]["min_minutes"] = 900
    impossible["constraints"][0]["max_minutes"] = 900
    result = solve(impossible)
    assert result["status"] == "INFEASIBLE"
    assert result["solution"] is None


def example(name):
    return json.loads((server.ROOT / f"backend/examples/{name}.json").read_text())


def test_compare_real_engine_and_repeated_baseline(app):
    payload = example("replan")
    code, pair = request(
        app,
        "/api/compare",
        json.dumps({"request": payload, "modes": ["preserve_assigned", "rebuild"]}),
    )
    assert code == 200
    assert [p["result"]["status"] for p in pair] == ["PARTIAL", "OPTIMAL"]
    assert [p["result"]["shortage_summary"]["total_person_minutes"] for p in pair] == [30, 0]
    assert all(p["result"]["verification"]["valid"] for p in pair)
    assert "fixed_parts" not in pair[1]["request"]
    assert all(o["metric"] != "plan_changes" for o in pair[1]["request"]["objectives"])
    source = {
        "id": "adopted",
        "request": pair[1]["request"],
        "solution": pair[1]["result"]["solution"],
    }
    code, snapshot = request(app, "/api/baseline", json.dumps(source))
    assert code == 200
    assert "baseline" not in snapshot["source_request"]
    assert "replan_mode" not in snapshot["source_request"]
    assert snapshot["snapshot_origin"]["replan_mode"] == "rebuild"
    code, again = request(
        app,
        "/api/compare",
        json.dumps(
            {"request": payload, "source": source, "modes": ["preserve_assigned", "rebuild"]}
        ),
    )
    assert code == 200 and all(p["result"]["verification"]["valid"] for p in again)


@pytest.mark.parametrize("failure_type", [ValueError, TypeError, RuntimeError])
def test_comparison_failure_keeps_sibling(app, monkeypatch, failure_type):
    import workflow

    real_solve = workflow.solve
    calls = []

    def fail_first(payload):
        calls.append(copy.deepcopy(payload))
        if len(calls) == 1:
            raise failure_type("private data")
        return real_solve(payload)

    monkeypatch.setattr(workflow, "solve", fail_first)
    _, pair = request(
        app,
        "/api/compare",
        json.dumps({"request": example("replan"), "modes": ["preserve_assigned", "rebuild"]}),
    )
    assert pair[0]["result"]["status"] == "ENGINE_ERROR"
    assert pair[1]["result"]["status"] == "OPTIMAL"
    assert calls[0]["solver"] == calls[1]["solver"]
    assert calls[0]["objectives"] == calls[1]["objectives"]
    assert "private data" not in json.dumps(pair)


def test_fixed_conflict_is_not_automatically_released(app):
    payload = example("replan")
    payload["employees"][0]["availability"] = []
    payload["shift_candidates"] = [
        c for c in payload["shift_candidates"] if c["employee_id"] != "alice"
    ]
    _, pair = request(
        app,
        "/api/compare",
        json.dumps({"request": payload, "modes": ["preserve_assigned", "rebuild"]}),
    )
    assert pair[0]["result"]["status"] == "INFEASIBLE"
    assert pair[1]["result"]["status"] == "PARTIAL"


def test_verify_edits_and_never_inherits_proofs(app):
    payload = example("complete")
    solution = solve(payload)["solution"]
    _, checked = request(app, "/api/verify", json.dumps({"request": payload, "solution": solution}))
    assert checked["status"] == "VALID"
    assert all(not o["proven_optimal"] for o in checked["objectives"])
    assert checked["shortage_summary"]["proven_minimal"] is False
    broken = copy.deepcopy(solution)
    broken["assignments"].append(copy.deepcopy(broken["assignments"][0]))
    _, checked = request(app, "/api/verify", json.dumps({"request": payload, "solution": broken}))
    assert checked["status"] == "INVALID_PLAN"
    assert checked["verification"]["valid"] is False
    assert checked["diagnostics"] or checked["verification"]["violations"]
    code, result = request(
        app,
        "/api/baseline",
        json.dumps({"id": "invalid", "request": payload, "solution": broken}),
    )
    assert code == 400 and result["error"] == "INVALID_OPERATION"


def test_verification_break_skill_and_minutes(app):
    payload = example("overnight")
    solution = solve(payload)["solution"]
    broken = copy.deepcopy(solution)
    broken["assignments"].append(
        {
            "employee_id": "alice",
            "role_id": "kitchen",
            "interval": {"start": "2026-10-06T23:30:00+09:00", "end": "2026-10-07T00:30:00+09:00"},
        }
    )
    _, checked = request(app, "/api/verify", json.dumps({"request": payload, "solution": broken}))
    assert checked["verification"]["valid"] is False
    payload = example("replan")
    payload.pop("replan_mode")
    payload.pop("baseline")
    solution = solve(payload)["solution"]
    broken = copy.deepcopy(solution)
    for assignment in broken["assignments"]:
        if assignment["role_id"] == "hall":
            assignment["employee_id"] = "bob"
    _, checked = request(app, "/api/verify", json.dumps({"request": payload, "solution": broken}))
    assert checked["verification"]["valid"] is False
    payload["constraints"] = [
        {
            "id": "too_high",
            "type": "scheduled_minutes_bounds",
            "employee_ids": ["alice"],
            "interval": payload["planning_window"] | {},
            "min_minutes": 180,
        }
    ]
    payload["constraints"][0]["interval"] = {
        k: payload["planning_window"][k] for k in ("start", "end")
    }
    _, checked = request(app, "/api/verify", json.dumps({"request": payload, "solution": solution}))
    assert checked["verification"]["valid"] is False


def saved_document(engine, payload, result):
    return {
        "format": "schedula-app/1",
        "engine": {key: engine[key] for key in ("version", "schema_version", "commit", "sha256")},
        "input": json.dumps(payload, ensure_ascii=False),
        "plans": [{"id": "plan", "label": "採用案", "request": payload, "result": result}],
        "selected": "plan",
        "baseline": "plan",
        "edit": None,
    }


@pytest.mark.parametrize("legacy_evidence", [False, True])
def test_restore_reverifies_and_preserves_input(app, legacy_evidence):
    payload = example("partial")
    result = solve(payload)
    document = saved_document(app.app.state.engine, payload, result)
    if legacy_evidence:
        document["plans"][0]["evidence"] = copy.deepcopy(result)
    code, restored = request(app, "/api/restore", json.dumps(document))
    assert code == 200
    plan = restored["plans"][0]
    assert plan["result"]["status"] == "PARTIAL"
    assert plan["result"]["shortage_summary"]["total_person_minutes"] == 30
    assert plan["result"]["shortage_summary"]["proven_minimal"] is False
    assert plan["evidence"] == {key: value for key, value in result.items() if key != "solution"}
    assert plan["result"]["solution"] == result["solution"]
    assert restored["input"] == document["input"]
    code, reloaded = request(app, "/api/restore", json.dumps(restored))
    assert code == 200
    assert reloaded["plans"][0]["evidence"] == plan["evidence"]
    assert reloaded["plans"][0]["result"]["solution"] == result["solution"]
    document["plans"][0]["result"]["solution"]["assignments"][0]["employee_id"] = "unknown"
    assert request(app, "/api/restore", json.dumps(document))[0] == 400


@pytest.mark.parametrize("mutation", ["format", "version", "reference", "duplicate_id", "schema"])
def test_bad_file_is_rejected(app, mutation):
    payload = example("complete")
    document = saved_document(app.app.state.engine, payload, solve(payload))
    if mutation == "format":
        document["format"] = "old"
    elif mutation == "version":
        document["engine"]["version"] = "0.1.3"
    elif mutation == "reference":
        document["selected"] = "missing"
    elif mutation == "duplicate_id":
        document["plans"].append(copy.deepcopy(document["plans"][0]))
    else:
        document["plans"][0]["request"]["schema_version"] = "unknown"
    assert request(app, "/api/restore", json.dumps(document))[0] == 400


def test_week_boundaries_and_dst(app):
    window = {
        "start": "2026-10-07T00:00:00+09:00",
        "end": "2026-10-15T00:00:00+09:00",
        "timezone": "Asia/Tokyo",
    }
    _, intervals = request(app, "/api/weeks", json.dumps(window))
    assert intervals == [
        {"start": "2026-10-07T00:00:00+09:00", "end": "2026-10-12T00:00:00+09:00"},
        {"start": "2026-10-12T00:00:00+09:00", "end": "2026-10-15T00:00:00+09:00"},
    ]
    window = {
        "start": "2026-10-26T00:00:00-04:00",
        "end": "2026-11-03T00:00:00-05:00",
        "timezone": "America/New_York",
    }
    _, intervals = request(app, "/api/weeks", json.dumps(window))
    assert intervals[0]["end"] == "2026-11-02T00:00:00-05:00"


@pytest.mark.parametrize(
    "path", ["solve", "compare", "verify", "baseline", "weeks", "restore", "parse"]
)
def test_all_new_http_routes_use_shared_boundary(app, path):
    assert request(app, f"/api/{path}", '{"x":1,"x":2}')[0] == 400
    assert (
        request(
            app,
            f"/api/{path}",
            "{}",
            {"Content-Type": "application/json", "Origin": "https://evil.example"},
        )[0]
        == 403
    )


@pytest.mark.parametrize("field", ["solver", "diagnosis"])
def test_search_budget_only_limits_exploration(app, field):
    payload = example("replan")
    payload[field] = {**payload.get(field, {}), "time_limit_seconds": 61}
    code, result = request(app, "/api/solve", json.dumps(payload))
    assert code == 400 and result["error"] == "SEARCH_LIMIT"
    code, result = request(
        app, "/api/compare", json.dumps({"request": payload, "modes": ["rebuild"]})
    )
    assert code == 400 and result["error"] == "SEARCH_LIMIT"
    assert request(app, "/api/parse", json.dumps(payload)) == (200, payload)
    # Verification and baseline construction do not explore, even when the source
    # request records a larger search budget.
    payload = example("complete")
    result = solve(payload)
    payload[field] = {**payload.get(field, {}), "time_limit_seconds": 61}
    if field == "diagnosis":
        payload[field].update(max_suggestions=0, allowed_changes=[])
    source = {"id": "plan", "request": payload, "solution": result["solution"]}
    code, checked = request(app, "/api/verify", json.dumps(source))
    assert code == 200 and checked["verification"]["valid"] is True
    assert request(app, "/api/baseline", json.dumps(source))[0] == 200
    document = saved_document(app.app.state.engine, payload, result)
    assert request(app, "/api/restore", json.dumps(document))[0] == 200


@pytest.mark.parametrize(
    "path,payload",
    [
        ("compare", {}),
        ("compare", {"request": {}, "modes": [{}]}),
        ("compare", {"request": {}, "modes": ["rebuild"], "source": {}}),
        ("verify", {}),
        ("baseline", {}),
        ("weeks", {}),
        ("weeks", {"start": "bad", "end": "bad", "timezone": "Unknown/Zone"}),
        ("restore", {}),
    ],
)
def test_invalid_operation_is_explicit_and_releases_lock(app, path, payload):
    code, result = request(app, f"/api/{path}", json.dumps(payload))
    assert code == 400 and result["error"] == "INVALID_OPERATION"
    assert request(app, "/api/solve", "{}")[0] == 200


@pytest.mark.parametrize("objectives", [None, {}, "invalid", 1, [None], [[]]])
@pytest.mark.parametrize("modes", [["rebuild"], ["preserve_assigned", "rebuild"]])
def test_malformed_rebuild_objectives_are_client_errors(app, objectives, modes):
    payload = {"request": {"baseline": {}, "objectives": objectives}, "modes": modes}
    code, result = request(app, "/api/compare", json.dumps(payload))
    assert code == 400 and result["error"] == "INVALID_OPERATION"
    assert request(app, "/api/solve", "{}")[0] == 200


@pytest.mark.parametrize("failure_type", [ValueError, KeyError, TypeError, RuntimeError])
@pytest.mark.parametrize("path", ["solve", "compare", "verify", "baseline", "restore", "weeks"])
def test_unexpected_failures_are_not_input_errors(app, monkeypatch, path, failure_type):
    function = {
        "solve": "solve",
        "compare": "compare",
        "verify": "checked_plan",
        "baseline": "baseline_snapshot",
        "restore": "restore",
        "weeks": "weeks",
    }[path]

    def fail(*args):
        raise failure_type("private input must not be returned")

    with monkeypatch.context() as patch:
        patch.setattr(server, function, fail)
        code, result = request(app, f"/api/{path}", "{}")
    assert code == 500 and result["error"] == "ENGINE_ERROR"
    assert "private input" not in json.dumps(result)
    assert request(app, "/api/solve", "{}")[0] == 200


def test_manual_employee_swap_and_candidate_change(app):
    payload = example("complete")
    solution = solve(payload)["solution"]
    swapped = copy.deepcopy(solution)
    for assignment in swapped["assignments"]:
        assignment["employee_id"] = "bob" if assignment["employee_id"] == "alice" else "alice"
    for shift in swapped["shifts"]:
        shift["employee_id"] = "bob" if shift["employee_id"] == "alice" else "alice"
        shift["candidate_id"] = next(
            c["id"]
            for c in payload["shift_candidates"]
            if c["employee_id"] == shift["employee_id"] and c["segments"] == shift["segments"]
        )
    _, checked = request(app, "/api/verify", json.dumps({"request": payload, "solution": swapped}))
    assert checked["status"] == "VALID"
    assert checked["objectives"][0]["value"] > 0
    # A different explicit candidate changes the break while keeping coverage valid.
    candidate = copy.deepcopy(payload["shift_candidates"][0])
    candidate["id"] = "alternate_break"
    candidate["segments"][0]["interval"]["end"] = "2026-10-05T12:00:00+09:00"
    candidate["segments"][0]["breaks"] = [
        {"start": "2026-10-05T11:00:00+09:00", "end": "2026-10-05T11:30:00+09:00"}
    ]
    payload["shift_candidates"].append(candidate)
    payload["employees"][0]["availability"][0]["end"] = "2026-10-05T12:00:00+09:00"
    changed = copy.deepcopy(solution)
    changed["shifts"][0]["candidate_id"] = candidate["id"]
    changed["shifts"][0]["segments"] = candidate["segments"]
    _, checked = request(app, "/api/verify", json.dumps({"request": payload, "solution": changed}))
    assert checked["status"] == "VALID"
    assert checked["objectives"][1]["value"] == 180


def test_week_clipping_uses_elapsed_time_and_requires_offset(app):
    window = {
        "start": "2026-11-01T01:30:00-04:00",
        "end": "2026-11-01T01:15:00-05:00",
        "timezone": "America/New_York",
    }
    code, intervals = request(app, "/api/weeks", json.dumps(window))
    assert code == 200 and intervals == [{"start": window["start"], "end": window["end"]}]
    window["start"] = "2026-11-01T01:30:00"
    assert request(app, "/api/weeks", json.dumps(window))[0] == 400


def test_explicit_change_objective_is_fixed_side_only(app):
    payload = example("replan")
    payload["objectives"].append({"id": "changes", "metric": "plan_changes"})
    payload["fixed_parts"] = [
        {
            "id": "keep",
            "employee_id": "alice",
            "interval": payload["demand"][0]["interval"],
            "components": ["work", "role"],
        }
    ]
    code, pair = request(
        app,
        "/api/compare",
        json.dumps({"request": payload, "modes": ["preserve_assigned", "rebuild"]}),
    )
    assert code == 200
    assert all(p["result"]["verification"]["valid"] for p in pair)
    assert [o["metric"] for o in pair[0]["request"]["objectives"]] == [
        "scheduled_minutes",
        "plan_changes",
    ]
    assert [o["metric"] for o in pair[1]["request"]["objectives"]] == ["scheduled_minutes"]
    assert pair[0]["request"]["fixed_parts"] == payload["fixed_parts"]
    assert "fixed_parts" not in pair[1]["request"]
