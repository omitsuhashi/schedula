import copy
import csv
import io
import json
import os
import sqlite3
import threading

import pytest
from fastapi.testclient import TestClient
from jsonschema import validate
from referencing import Registry, Resource
from test_app import example

import commands
import server
from store import StateError, Store


@pytest.fixture
def client(tmp_path):
    server.app.state.data_dir = tmp_path / "data"
    with TestClient(server.app, base_url="http://127.0.0.1:8765") as client:
        yield client


def send(client, path, body, method="POST", status=200):
    response = client.request(
        method, path, content=json.dumps(body), headers={"Content-Type": "application/json"}
    )
    assert response.status_code == status, response.text[:500]
    return response.json()


def create(client, input="unfinished {"):
    return send(client, "/api/sessions", {"input": input}, status=201)["session_id"]


def command(client, sid, operation, body=None, version=None, status=200, method="POST"):
    if version is None:
        version = client.get(f"/api/sessions/{sid}").json()["version"]
    return send(
        client,
        f"/api/sessions/{sid}/{operation}",
        {"expected_version": version, **(body or {})},
        method,
        status,
    )


def solved(client, sid, name="complete"):
    result = command(client, sid, "plans", {"request": example(name)}, status=201)
    return result["plan_ids"][0]


@pytest.mark.parametrize(
    "name",
    [
        "complete",
        "partial",
        "overnight",
        "split",
        "continuity_month",
        "scheduled_cost",
        "duty_balance",
    ],
)
def test_real_commands_queries_json_restart(client, name):
    sid = create(client)
    base = f"/api/sessions/{sid}"
    pid = solved(client, sid, name)
    detail = client.get(f"{base}/plans/{pid}").json()
    assert detail["request"] == example(name)
    assert detail["result"]["verification"]["valid"] is True
    result = command(client, sid, "adopt", {"plan_id": pid})
    assert result["version"] == 2
    assert result["result"]["demand_satisfied"] == (name != "partial")
    state = client.get(base).json()
    assert state["selected"] == state["baseline"] == pid
    next_input = json.loads(state["input"])
    assert "fixed_parts" not in next_input and "replan_mode" not in next_input
    assert next_input["baseline"]["source_solution"] == detail["result"]["solution"]
    assert not any(o["metric"] == "plan_changes" for o in next_input["objectives"])
    monthly = client.get(f"{base}/plans/{pid}/monthly").json()
    assert monthly["employees"] and monthly["dates"]
    assert monthly["status"] == detail["result"]["status"]
    for e in monthly["employees"]:
        person = client.get(f"{base}/plans/{pid}/employees/{e['employee_id']}").json()
        assert person["summary"] == e["summary"]
    for kind in ("monthly", "shifts", "demand"):
        response = client.get(f"{base}/exports/{kind}")
        assert response.status_code == 200 and response.content.startswith(b"\xef\xbb\xbf")
        assert "attachment" in response.headers["content-disposition"]
        assert len(list(csv.reader(io.StringIO(response.text)))) > 1
    document = client.get(f"{base}/export").json()
    assert set(document) == {"format", "engine", "input", "plans", "selected", "baseline", "edit"}
    imported = send(client, "/api/sessions/import", document, status=201)
    imported2 = send(client, "/api/sessions/import", document, status=201)
    assert imported["session_id"] != imported2["session_id"] != sid
    assert imported["plan_ids"] == [pid]
    state2 = client.get(f"/api/sessions/{imported['session_id']}/plans/{pid}").json()
    assert state2["result"]["solution"] == detail["result"]["solution"]
    assert all(not o["proven_optimal"] for o in state2["result"]["objectives"])
    assert not state2["result"]["shortage_summary"]["proven_minimal"]
    assert "solution" not in state2["evidence"]
    from workflow import restore

    restore(
        client.get(f"/api/sessions/{imported['session_id']}/export").json(), client.app.state.engine
    )
    reopened = Store(client.app.state.data_dir, client.app.state.engine)
    assert reopened.read(sid) == client.app.state.store.read(sid)
    assert reopened.path.stat().st_mode & 0o777 == 0o600
    assert reopened.path.parent.stat().st_mode & 0o777 == 0o700


def test_version_drafts_and_transaction_rollback(client, monkeypatch):
    sid = create(client)
    base = f"/api/sessions/{sid}"
    edit = {"request": {}, "solution": {}}
    command(client, sid, "draft", {"input": "{incomplete", "edit": edit}, version=0, method="PUT")
    before = client.app.state.store.read(sid)
    conflict = command(
        client, sid, "draft", {"input": "other", "edit": None}, version=0, method="PUT", status=409
    )
    assert conflict["error"] == "VERSION_CONFLICT" and conflict["current_version"] == 1
    for version in (True, "1", 1.0, -1):
        assert (
            command(
                client,
                sid,
                "draft",
                {"input": "", "edit": None},
                version=version,
                method="PUT",
                status=400,
            )["error"]
            == "INVALID_OPERATION"
        )
    original = client.app.state.store.insert_plans

    def fail(db, sid, plans):
        original(db, sid, plans)
        raise sqlite3.OperationalError("injected disk full")

    monkeypatch.setattr(client.app.state.store, "insert_plans", fail)
    assert (
        command(client, sid, "plans", {"request": example("complete")}, status=500)["error"]
        == "STORAGE_ERROR"
    )
    assert client.app.state.store.read(sid) == before
    assert client.get(base).json()["edit"] == edit


def test_comparison_edits_ancestor_deletion_and_partial(client, monkeypatch):
    sid = create(client)
    pid = solved(client, sid, "partial")
    command(client, sid, "adopt", {"plan_id": pid})
    req = json.loads(client.get(f"/api/sessions/{sid}").json()["input"])
    result = command(
        client,
        sid,
        "comparisons",
        {"request": req, "modes": ["preserve_assigned", "rebuild"]},
        status=201,
    )
    ids = result["plan_ids"]
    comparison = client.get(
        f"/api/sessions/{sid}/comparisons", params=[("plan_id", i) for i in ids]
    ).json()
    assert [p["plan_id"] for p in comparison["plans"]] == ids
    assert all(p["employee_totals"] for p in comparison["plans"])
    detail = client.get(f"/api/sessions/{sid}/plans/{ids[1]}").json()
    assert "fixed_parts" not in detail["request"]
    checked = command(
        client,
        sid,
        f"plans/{ids[1]}/edits",
        {"request": detail["request"], "solution": detail["result"]["solution"]},
        status=201,
    )
    edited_id = checked["plan_ids"][0]
    edited = client.get(f"/api/sessions/{sid}/plans/{edited_id}").json()
    assert all(not o["proven_optimal"] for o in edited["result"]["objectives"])
    command(client, sid, "adopt", {"plan_id": edited_id})
    command(client, sid, f"plans/{pid}", method="DELETE")
    assert client.get(f"/api/sessions/{sid}/plans/{pid}").status_code == 404
    command(client, sid, "adopt", {"plan_id": edited_id})
    command(client, sid, f"plans/{edited_id}", method="DELETE", status=409)
    broken = copy.deepcopy(edited["result"]["solution"])
    broken["shifts"][0]["employee_id"] = "absent"
    before = client.app.state.store.read(sid)
    failed = command(
        client,
        sid,
        f"plans/{edited_id}/edits",
        {"request": edited["request"], "solution": broken},
        status=400,
    )
    assert failed["error"] == "INVALID_PLAN"
    assert client.app.state.store.read(sid) == before
    original = commands.compare.__globals__["solve"]

    def one_failure(request):
        if request.get("replan_mode") == "preserve_assigned":
            raise RuntimeError("injected")
        return original(request)

    monkeypatch.setitem(commands.compare.__globals__, "solve", one_failure)
    result = command(
        client,
        sid,
        "comparisons",
        {"request": req, "modes": ["preserve_assigned", "rebuild"]},
        status=201,
    )
    assert result["result"]["statuses"][0] == "ENGINE_ERROR"
    assert len(result["plan_ids"]) == 2
    command(client, sid, "adopt", {"plan_id": result["plan_ids"][0]}, status=409)


def test_query_never_calculates_or_writes_and_inflight_conflict(client, monkeypatch):
    sid = create(client)
    pid = solved(client, sid)
    command(client, sid, "adopt", {"plan_id": pid})
    store = client.app.state.store
    before = store.read(sid)
    started, release = threading.Event(), threading.Event()
    original = commands.solve

    def delayed(request):
        started.set()
        assert release.wait(10)
        return original(request)

    monkeypatch.setattr(commands, "solve", delayed)
    responses = []
    version = before["version"]
    thread = threading.Thread(
        target=lambda: responses.append(
            client.post(
                f"/api/sessions/{sid}/plans",
                json={"expected_version": version, "request": example("complete")},
            )
        )
    )
    thread.start()
    assert started.wait(5)
    try:

        def forbidden(*args, **kwargs):
            raise AssertionError("Query invoked engine")

        monkeypatch.setattr(commands, "checked_plan", forbidden)
        monkeypatch.setattr(commands, "baseline_snapshot", forbidden)
        base = f"/api/sessions/{sid}"
        for path in (
            "",
            "/",
            "/plans",
            f"/plans/{pid}",
            f"/plans/{pid}/monthly",
            f"/plans/{pid}/employees/alice",
            f"/comparisons?plan_id={pid}",
            "/export",
            "/exports/monthly",
            "/exports/shifts",
            "/exports/demand",
        ):
            assert client.get(base + path).status_code == 200
        assert store.read(sid) == before
        command(
            client, sid, "draft", {"input": "newer", "edit": None}, version=version, method="PUT"
        )
    finally:
        release.set()
        thread.join(10)
    assert responses[0].status_code == 409
    after = store.read(sid)
    assert after["version"] == version + 1 and after["input"] == "newer"
    assert after["plans"] == before["plans"]


def test_reject_imports_no_partial_rows_and_unusable_adoption(client):
    sid = create(client)
    pid = solved(client, sid)
    document = client.get(f"/api/sessions/{sid}/export").json()
    before = client.app.state.store.read(sid)
    cases = []
    for mutate in (
        lambda d: d["plans"].append(copy.deepcopy(d["plans"][0])),
        lambda d: d.update(selected="absent"),
    ):
        d = copy.deepcopy(document)
        mutate(d)
        cases.append(d)
    for d in cases:
        assert send(client, "/api/sessions/import", d, status=400)["error"] == "INVALID_OPERATION"
        assert client.app.state.store.session_ids() == [sid]
        assert client.app.state.store.read(sid) == before
    other = create(client)
    command(client, other, "adopt", {"plan_id": pid}, status=404)
    command(client, sid, "adopt", {"plan_id": pid, "verification": {"valid": True}}, status=400)
    failed = command(client, sid, "plans", {"request": {}}, status=201)["plan_ids"][0]
    command(client, sid, "adopt", {"plan_id": failed}, status=409)
    assert client.get(f"/api/sessions/{sid}/plans/{failed}/monthly").status_code == 409
    for path in (
        "/api/sessions/unknown",
        f"/api/sessions/{sid}/plans/unknown",
        f"/api/sessions/{sid}/plans/{pid}/employees/unknown",
    ):
        assert client.get(path).status_code == 404


def test_import_invalid_plan_returns_verification_without_partial_rows(client):
    sid = create(client)
    solved(client, sid)
    document = client.get(f"/api/sessions/{sid}/export").json()
    before = client.app.state.store.read(sid)
    invalid = {**copy.deepcopy(document["plans"][0]), "id": "second"}
    invalid["result"]["solution"]["assignments"].append(
        copy.deepcopy(invalid["result"]["solution"]["assignments"][0])
    )
    document["plans"].append(invalid)
    response = send(client, "/api/sessions/import", document, status=400)
    assert response["error"] == "INVALID_PLAN"
    checked = response["result"]
    assert checked["verification"]["valid"] is False
    assert checked["diagnostics"] or checked["verification"]["violations"]
    assert checked["solution"] == invalid["result"]["solution"]
    assert client.app.state.store.session_ids() == [sid]
    assert client.app.state.store.read(sid) == before
    assert send(client, "/api/restore", document, status=400)["error"] == "INVALID_OPERATION"


@pytest.mark.parametrize("field", ["format", "version", "schema_version", "commit", "sha256"])
def test_import_compatibility_error_keeps_existing_sessions(client, field):
    sid = create(client)
    document = client.get(f"/api/sessions/{sid}/export").json()
    before = client.app.state.store.read(sid)
    if field == "format":
        document[field] = "schedula-app/obsolete"
    else:
        document["engine"][field] = "other"
    response = send(client, "/api/sessions/import", document, status=409)
    assert response["error"] == "INCOMPATIBLE_VERSION"
    assert client.app.state.store.session_ids() == [sid]
    assert client.app.state.store.read(sid) == before
    # The stateless legacy endpoint retains its existing 400 contract.
    assert send(client, "/api/restore", document, status=400)["error"] == "INVALID_OPERATION"
    document.pop("format")
    assert (
        send(client, "/api/sessions/import", document, status=400)["error"] == "INVALID_OPERATION"
    )
    assert client.app.state.store.session_ids() == [sid]


def test_schema_pin_corruption_and_foreign_keys(client, tmp_path):
    store = client.app.state.store
    sid = create(client)
    pid = solved(client, sid)
    before = store.read(sid)
    state = store.read(sid)
    state["selected"] = "other"
    with pytest.raises(StateError):
        store.update(state, state["version"])
    assert store.read(sid) == before
    with pytest.raises(StateError):
        with store.connection(write=True) as db:
            db.execute("UPDATE sessions SET selected=? WHERE id=?", ("absent", sid))
    assert store.read(sid) == before
    with pytest.raises(StateError):
        store.create({"input": "", "plans": [before["plans"][0], before["plans"][0]]})
    assert store.session_ids() == [sid]
    with pytest.raises(StateError):
        Store(store.path.parent, {**store.engine, "version": "incompatible"})
    assert store.read(sid) == before
    corrupt = tmp_path / "broken"
    corrupt.mkdir(mode=0o700)
    (corrupt / "sessions.sqlite3").write_bytes(b"not sqlite")
    with pytest.raises(StateError):
        Store(corrupt, store.engine)
    assert (corrupt / "sessions.sqlite3").read_bytes() == b"not sqlite"
    assert pid == before["plans"][0]["id"]


@pytest.mark.parametrize("kind", ["shared", "sticky", "unrelated", "symlink", "other-owner"])
def test_unsafe_data_directory_is_unchanged(client, tmp_path, monkeypatch, kind):
    directory = tmp_path / "existing"
    directory.mkdir(mode=0o700)
    if kind in {"sticky", "unrelated"}:
        (directory / "other-service.txt").write_text("keep")
    if kind in {"shared", "sticky"}:
        directory.chmod(0o755 if kind == "shared" else 0o1777)
    supplied = directory
    if kind == "symlink":
        supplied = tmp_path / "link"
        supplied.symlink_to(directory, target_is_directory=True)
    if kind == "other-owner":
        other_uid = os.getuid() + 1
        monkeypatch.setattr(os, "getuid", lambda: other_uid)
    before = directory.stat().st_mode
    contents = {entry.name: entry.read_bytes() for entry in directory.iterdir()}
    with pytest.raises(StateError, match="専用ディレクトリ"):
        Store(supplied, client.app.state.engine)
    assert directory.stat().st_mode == before
    assert {entry.name: entry.read_bytes() for entry in directory.iterdir()} == contents


def test_new_and_prepared_private_data_directories(client, tmp_path):
    parent = tmp_path / "parent"
    parent.mkdir(mode=0o755)
    before = parent.stat().st_mode
    prepared = parent / "prepared"
    prepared.mkdir(mode=0o700)
    for directory in (parent / "new", prepared):
        store = Store(directory, client.app.state.engine)
        sid = store.create({"input": "unfinished"})
        assert directory.stat().st_mode & 0o777 == 0o700
        assert store.path.stat().st_mode & 0o777 == 0o600
        assert Store(directory, store.engine).read(sid) == store.read(sid)
    assert parent.stat().st_mode == before


@pytest.mark.parametrize(
    "name",
    [
        "sessions.sqlite3",
        "sessions.sqlite3-journal",
        "sessions.sqlite3-wal",
        "sessions.sqlite3-shm",
    ],
)
def test_hard_linked_database_files_are_rejected_without_mutation(client, tmp_path, name):
    outside = tmp_path / "outside.sqlite3"
    outside.write_bytes(client.app.state.store.path.read_bytes())
    outside.chmod(0o644)
    directory = tmp_path / "dedicated"
    directory.mkdir(mode=0o700)
    os.link(outside, directory / name)
    before = outside.read_bytes(), outside.stat().st_mode
    with pytest.raises(StateError, match="専用ディレクトリ"):
        Store(directory, client.app.state.engine)
    assert (outside.read_bytes(), outside.stat().st_mode) == before
    assert outside.stat().st_nlink == 2
    assert [entry.name for entry in directory.iterdir()] == [name]


def test_json_limits_strict_boundary_and_csv_formula(client, monkeypatch):
    sid = create(client, "x" * (server.MAX_BODY_BYTES - 1000))
    base = f"/api/sessions/{sid}"
    document = client.get(base + "/export").json()
    send(client, "/api/sessions/import", document, status=201)
    pid = solved(client, sid)
    assert client.get(base + "/export").status_code == 413
    command(client, sid, f"plans/{pid}", method="DELETE")
    assert client.get(base + "/export").status_code == 200
    for raw, status in (('{"input":"","input":""}', 400), ("x" * (server.MAX_BODY_BYTES + 1), 413)):
        assert (
            client.post(
                "/api/sessions/import", content=raw, headers={"Content-Type": "application/json"}
            ).status_code
            == status
        )
    sid = create(client)
    req = example("overnight")
    req["employees"][0]["label"] = ' =SUM(1)\n"名称"'
    pid = command(client, sid, "plans", {"request": req}, status=201)["plan_ids"][0]
    command(client, sid, "adopt", {"plan_id": pid})
    text = client.get(f"/api/sessions/{sid}/exports/monthly").text
    assert list(csv.reader(io.StringIO(text)))[1][2] == '\' =SUM(1)\n"名称"'
    # The CSV path never uses the JSON body/export limit.
    monkeypatch.setattr(server, "MAX_BODY_BYTES", 100)
    assert client.get(f"/api/sessions/{sid}/exports/shifts").status_code == 200


def test_openapi_matches_session_dtos(client):
    document = client.get("/openapi.json").json()
    from fastapi.openapi.models import OpenAPI

    OpenAPI.model_validate(document)
    registry = Registry().with_resource(
        "https://app.test/schema",
        Resource.from_contents(
            {"$schema": "https://json-schema.org/draft/2020-12/schema", **document}
        ),
    )
    sid = create(client)
    pid = solved(client, sid)
    command(client, sid, "adopt", {"plan_id": pid})
    for schema, path in [
        ("SessionOverview", f"/api/sessions/{sid}"),
        ("PlanList", f"/api/sessions/{sid}/plans"),
        ("PlanDetail", f"/api/sessions/{sid}/plans/{pid}"),
        ("MonthlyView", f"/api/sessions/{sid}/plans/{pid}/monthly"),
        ("EmployeeView", f"/api/sessions/{sid}/plans/{pid}/employees/alice"),
        ("ComparisonView", f"/api/sessions/{sid}/comparisons?plan_id={pid}"),
    ]:
        validate(
            client.get(path).json(),
            {"$ref": f"https://app.test/schema#/components/schemas/{schema}"},
            registry=registry,
        )
    ids = [
        operation["operationId"]
        for path in document["paths"].values()
        for operation in path.values()
        if isinstance(operation, dict) and "operationId" in operation
    ]
    assert len(ids) == len(set(ids))


def test_backup_wal_restore_and_customer_isolation(client, tmp_path):
    from storage_admin import backup, restore_backup

    a = client.app.state.store
    sid = create(client)
    solved(client, sid, "partial")
    b = Store(tmp_path / "customer-b", a.engine)
    bid = b.create({"input": "customer B"})
    before_b = b.read(bid)
    before_a = a.read(sid)
    snapshot = tmp_path / "snapshot.sqlite3"
    with a.connection(write=True) as connection:
        connection.execute("PRAGMA journal_mode=WAL")
        command(client, sid, "draft", {"input": "committed WAL", "edit": None}, method="PUT")
        expected = a.read(sid)
        assert (a.path.parent / "sessions.sqlite3-wal").exists()
        meta = backup(a.path.parent, snapshot, a.engine)
    assert meta["db_schema_version"] == 1
    restored = tmp_path / "restored-a"
    result = restore_backup(snapshot, restored, a.engine)
    assert result["plans_rechecked"] == 1
    assert Store(restored, a.engine).read(sid) == expected
    assert b.read(bid) == before_b
    with pytest.raises(ValueError):
        restore_backup(snapshot, a.path.parent, a.engine)
    assert a.read(sid) == expected
    with pytest.raises(ValueError):
        restore_backup(snapshot, tmp_path / "wrong-engine", {**a.engine, "version": "wrong"})
    snapshot.write_bytes(b"corrupt")
    with pytest.raises(ValueError):
        restore_backup(snapshot, tmp_path / "failed-restore", a.engine)
    assert not (tmp_path / "failed-restore").exists()
    assert b.read(bid) == before_b and a.read(sid) != before_a


def test_restore_rejects_backup_changed_before_copy(client, tmp_path, monkeypatch):
    import storage_admin

    store = client.app.state.store
    sid = create(client)
    before = store.read(sid)
    snapshot = tmp_path / "snapshot.sqlite3"
    storage_admin.backup(store.path.parent, snapshot, store.engine)
    other = Store(tmp_path / "other", store.engine)
    other_id = other.create({"input": "different valid database"})
    before_other = other.read(other_id)
    replacement = tmp_path / "replacement.sqlite3"
    storage_admin.backup(other.path.parent, replacement, store.engine)
    copyfile = storage_admin.shutil.copyfile

    def changed_source(source, target):
        source.write_bytes(replacement.read_bytes())
        return copyfile(source, target)

    monkeypatch.setattr(storage_admin.shutil, "copyfile", changed_source)
    destination = tmp_path / "restored"
    with pytest.raises(ValueError, match="ハッシュ"):
        storage_admin.restore_backup(snapshot, destination, store.engine)
    assert not destination.exists()
    assert not list(tmp_path.glob("schedula-restore-*"))
    assert store.read(sid) == before
    assert other.read(other_id) == before_other


def test_read_model_elapsed_dst_and_continuity():
    from zoneinfo import ZoneInfo

    from queries import days, person_summary, waiting_intervals

    request = example("overnight")
    solution = {
        "shifts": [
            {
                "candidate_id": c["id"],
                "employee_id": c["employee_id"],
                "work_day": c["segments"][0]["interval"]["start"][:10],
                "segments": c["segments"],
            }
            for c in request["shift_candidates"]
        ],
        "assignments": [],
    }
    s = person_summary(request, solution, "alice")
    assert s["minutes"] == s["waiting"] == 420 and s["work_days"] == 1 and s["holidays"] == 0
    interval = {"start": "2026-11-01T00:00:00-04:00", "end": "2026-11-01T02:00:00-05:00"}
    request["planning_window"] = {**interval, "timezone": "America/New_York", "slot_minutes": 30}
    solution["shifts"][0].update(
        work_day="2026-11-01", segments=[{"interval": interval, "breaks": []}]
    )
    assert days(request) == ["2026-11-01"]
    assert person_summary(request, solution, "alice")["minutes"] == 180
    assert (
        len(
            list(
                waiting_intervals(solution["shifts"][0], [], interval, ZoneInfo("America/New_York"))
            )
        )
        == 1
    )
    request = example("continuity_month")
    history = request["continuity"]["employees"][0]
    night = history["committed_shifts"][0]
    request["constraints"].append(
        {
            "id": "context",
            "type": "scheduled_minutes_bounds",
            "employee_ids": ["alice"],
            "interval": {"start": "2026-10-31T00:00:00+09:00", "end": "2026-11-03T00:00:00+09:00"},
        }
    )
    solution = {
        "assignments": [],
        "shifts": [
            {
                "employee_id": "alice",
                "committed_shift_id": night["id"],
                "work_day": "2026-10-31",
                "segments": night["segments"],
            }
        ],
    }
    summary = person_summary(request, solution, "alice")
    assert summary["minutes"] == 300 and summary["bounds"][-1]["actual"] == 480


def test_adoption_rechecks_stored_solution_even_with_forged_flags(client, monkeypatch):
    sid = create(client)
    original = commands.solve(example("complete"))
    broken = copy.deepcopy(original)
    broken["solution"]["shifts"][0]["employee_id"] = "unknown"
    monkeypatch.setattr(commands, "solve", lambda request: broken)
    pid = solved(client, sid)
    before = client.app.state.store.read(sid)
    command(client, sid, "adopt", {"plan_id": pid}, status=409)
    assert client.app.state.store.read(sid) == before
    broken["verification"]["performed"] = False
    pid = solved(client, sid)
    command(client, sid, "adopt", {"plan_id": pid}, status=409)


def test_comparison_setup_failure_preserves_state(client, monkeypatch):
    sid = create(client)
    pid = solved(client, sid)
    before = client.app.state.store.read(sid)

    def failed(source):
        raise RuntimeError("unexpected baseline preparation failure")

    monkeypatch.setitem(commands.compare.__globals__, "baseline_snapshot", failed)
    command(
        client,
        sid,
        "comparisons",
        {"request": example("complete"), "modes": ["rebuild"], "baseline_plan_id": pid},
        status=500,
    )
    assert client.app.state.store.read(sid) == before
