"""Application snapshots and file boundary, using only schedula's public API."""

import copy
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from shift_schedula import make_baseline, solve, verify


class InvalidOperation(ValueError):
    """Invalid application input, distinct from an unexpected engine failure."""


class IncompatibleVersion(InvalidOperation):
    """Unsupported saved format or engine pin."""


class InvalidPlan(InvalidOperation):
    def __init__(self, message, result):
        super().__init__(message)
        self.result = result


def checked_plan(request, solution):
    if not isinstance(request, dict) or not isinstance(solution, dict):
        raise InvalidOperation("元入力と解をオブジェクトで指定してください。")
    return {**verify(request, solution), "solution": copy.deepcopy(solution)}


def baseline_snapshot(source):
    if (
        not isinstance(source, dict)
        or not isinstance(source.get("request"), dict)
        or not isinstance(source.get("solution"), dict)
        or not isinstance(source.get("id"), str)
    ):
        raise InvalidOperation("基準計画のID・元入力・解を指定してください。")
    try:
        return make_baseline(source["request"], source["solution"], source["id"])
    except ValueError as failure:
        # The public make_baseline contract reports invalid plans with ValueError.
        raise InvalidOperation(str(failure)) from failure


def compare(payload):
    original = payload.get("request")
    modes = payload.get("modes")
    if not isinstance(original, dict) or not isinstance(modes, list) or not modes:
        raise InvalidOperation("再計画の入力と方式を指定してください。")
    if len(modes) > 2 or any(mode not in ("preserve_assigned", "rebuild") for mode in modes):
        raise InvalidOperation("再計画の方式が不正です。")
    objectives = original.get("objectives", [])
    if "rebuild" in modes and (
        not isinstance(objectives, list) or any(not isinstance(item, dict) for item in objectives)
    ):
        raise InvalidOperation("再計画の目的はオブジェクトの配列で指定してください。")
    baseline = copy.deepcopy(original.get("baseline"))
    if "source" in payload:
        baseline = baseline_snapshot(payload["source"])
    if baseline is None:
        raise InvalidOperation("検証済みの基準計画を選んでください。")
    results = []
    for mode in modes:
        request = copy.deepcopy(original)
        request["baseline"] = copy.deepcopy(baseline)
        request["replan_mode"] = mode
        # Common objectives keep their order; only an explicitly requested fixed-side
        # change objective is retained. Rebuild never inherits it.
        if mode == "rebuild":
            request.pop("fixed_parts", None)
            request["objectives"] = [
                item
                for item in request.get("objectives", [])
                if item.get("metric") != "plan_changes"
            ]
        try:
            result = solve(request)
        except Exception:
            # Keep the sibling result even if one engine call fails.
            result = {
                "status": "ENGINE_ERROR",
                "solution": None,
                "verification": {"performed": False, "valid": None},
            }
        results.append({"mode": mode, "request": request, "result": result})
    return results


def weeks(window):
    if any(not isinstance(window.get(key), str) for key in ("start", "end", "timezone")):
        raise InvalidOperation("計画期間の開始・終了・タイムゾーンを文字列で指定してください。")
    try:
        zone = ZoneInfo(window["timezone"])
        values = [datetime.fromisoformat(window[key]) for key in ("start", "end")]
    except (ValueError, ZoneInfoNotFoundError) as failure:
        raise InvalidOperation("計画期間の日時・タイムゾーンを確認してください。") from failure
    if any(value.utcoffset() is None for value in values):
        raise InvalidOperation("計画期間の日時にはオフセットが必要です。")
    start, end = (value.astimezone(zone) for value in values)
    if start.timestamp() >= end.timestamp() or (end.timestamp() - start.timestamp()) > 366 * 86400:
        raise InvalidOperation("計画期間を確認してください。")
    monday = start.date() - timedelta(days=start.weekday())
    result = []
    while (left := datetime.combine(monday, time(), zone)).timestamp() < end.timestamp():
        right = datetime.combine(monday + timedelta(days=7), time(), zone)
        result.append(
            {
                "start": max(start, left, key=datetime.timestamp).isoformat(),
                "end": min(end, right, key=datetime.timestamp).isoformat(),
            }
        )
        monday += timedelta(days=7)
    return result


def restore(document, engine):
    fields = {"format", "engine", "input", "plans", "selected", "baseline", "edit"}
    if set(document) != fields:
        raise InvalidOperation("保存ファイルの必須項目・未対応項目を確認してください。")
    if document["format"] != "schedula-app/1":
        raise IncompatibleVersion(
            "保存形式が未対応です。schedula-app/1 のファイルを選んでください。"
        )
    pin = {key: engine[key] for key in ("version", "schema_version", "commit", "sha256")}
    if document["engine"] != pin:
        raise IncompatibleVersion("保存ファイルのエンジン版・Schema・配布物が一致しません。")
    if not isinstance(document["input"], str) or not isinstance(document["plans"], list):
        raise InvalidOperation("保存ファイルの入力・計画一覧が不正です。")
    restored = copy.deepcopy(document)
    ids = set()
    usable = set()
    for plan in restored["plans"]:
        if not isinstance(plan, dict) or set(plan) - {
            "id",
            "label",
            "request",
            "result",
            "evidence",
        }:
            raise InvalidOperation("保存ファイルの計画が不正です。")
        if (
            not isinstance(plan.get("id"), str)
            or not isinstance(plan.get("label"), str)
            or plan["id"] in ids
            or not isinstance(plan.get("request"), dict)
            or not isinstance(plan.get("result"), dict)
        ):
            raise InvalidOperation("保存ファイルのID・参照・入力が不正です。")
        ids.add(plan["id"])
        solution = plan["result"].get("solution")
        plan["evidence"] = plan.get("evidence", plan["result"])
        if isinstance(plan["evidence"], dict):
            plan["evidence"].pop("solution", None)
        if solution is not None:
            if (
                plan["request"].get("schema_version") != engine["schema_version"]
                or plan["request"].get("problem_type") != "roster"
            ):
                raise InvalidOperation(
                    f"計画のSchema・種類が未対応です。契約{engine['schema_version']}の勤務計画を指定してください。"
                )
            checked = checked_plan(plan["request"], solution)
            if checked["verification"]["valid"] is not True:
                raise InvalidPlan(f"計画 {plan['id']} の再検証に失敗しました。", checked)
            plan["result"] = checked
            usable.add(plan["id"])
        else:
            # Failed comparison attempts are evidence, never adoptable plans.
            plan["result"] = {
                "status": "NO_PLAN",
                "solution": None,
                "verification": {"performed": False, "valid": None},
            }
    for key in ("selected", "baseline"):
        if document[key] is not None and (
            not isinstance(document[key], str) or document[key] not in usable
        ):
            raise InvalidOperation("採用案・基準計画の参照が不正です。")
    if document["edit"] is not None:
        edit = document["edit"]
        if not isinstance(edit, dict) or set(edit) != {"request", "solution"}:
            raise InvalidOperation("修正途中の形式が不正です。")
        if not isinstance(edit["request"], dict) or not isinstance(edit["solution"], dict):
            raise InvalidOperation("修正途中の入力・解が不正です。")
        # A draft remains unverified; it is never a selected or baseline plan.
    return restored
